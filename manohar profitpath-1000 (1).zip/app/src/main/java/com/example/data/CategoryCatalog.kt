package com.example.data

import com.example.model.BilingualText
import com.example.model.IdeaCategory

object CategoryCatalog {
    val allCategories: List<IdeaCategory> = listOf(
        IdeaCategory(
            id = "youtube",
            name = BilingualText("YouTube & Video Creation", "यूट्यूब और वीडियो क्रिएशन"),
            subtitle = BilingualText("Faceless channels, Shorts, reviews & tutorials", "फेसलेस चैनल, शॉर्ट्स, रिव्यू और ट्यूटोरियल"),
            iconKey = "video",
            accentHex = 0xFFD93829
        ),
        IdeaCategory(
            id = "affiliate",
            name = BilingualText("Affiliate Marketing", "एफिलिएट मार्केटिंग"),
            subtitle = BilingualText("Product reviews, comparison blogs & deal channels", "प्रोडक्ट रिव्यू, डील्स चैनल और कमीशन कमाई"),
            iconKey = "link",
            accentHex = 0xFF0E7490
        ),
        IdeaCategory(
            id = "freelancing",
            name = BilingualText("Freelancing & Skills", "फ्रीलांसिंग और स्किल्स"),
            subtitle = BilingualText("Design, editing, coding, copywriting & VA", "डिज़ाइन, एडिटिंग, कोडिंग और वर्चुअल असिस्टेंट"),
            iconKey = "laptop",
            accentHex = 0xFF2563EB
        ),
        IdeaCategory(
            id = "student",
            name = BilingualText("Student Part-Time", "छात्र पार्ट-टाइम कमाई"),
            subtitle = BilingualText("Flexible campus & weekend earning options", "कॉलेज के साथ फ्लेक्सिबल और वीकेंड कमाई"),
            iconKey = "school",
            accentHex = 0xFF7C3AED
        ),
        IdeaCategory(
            id = "wfh",
            name = BilingualText("Work From Home", "वर्क फ्रॉम होम"),
            subtitle = BilingualText("Remote jobs, support roles & home studios", "रिमोट जॉब्स, कस्टमर सपोर्ट और घर से काम"),
            iconKey = "home",
            accentHex = 0xFF0D9488
        ),
        IdeaCategory(
            id = "zero_invest",
            name = BilingualText("Zero-Investment Online", "जीरो-इन्वेस्टमेंट ऑनलाइन"),
            subtitle = BilingualText("Start today with ₹0 upfront capital", "बिना किसी शुरुआती पूंजी के आज ही शुरू करें"),
            iconKey = "bolt",
            accentHex = 0xFF15803D
        ),
        IdeaCategory(
            id = "digital_products",
            name = BilingualText("Digital Products", "डिजिटल प्रोडक्ट्स"),
            subtitle = BilingualText("Templates, ebooks, planners & micro-courses", "टेम्पलेट्स, ई-बुक्स, प्लानर और मिनी कोर्स"),
            iconKey = "layers",
            accentHex = 0xFF9333EA
        ),
        IdeaCategory(
            id = "blogging",
            name = BilingualText("Blogging & Content Writing", "ब्लॉगिंग और कंटेंट राइटिंग"),
            subtitle = BilingualText("Niche blogs, newsletters & SEO writing", "नीश ब्लॉग, न्यूज़लेटर और एसईओ राइटिंग"),
            iconKey = "article",
            accentHex = 0xFFB45309
        ),
        IdeaCategory(
            id = "ecommerce",
            name = BilingualText("E-Commerce & Reselling", "ई-कॉमर्स और रीसेलिंग"),
            subtitle = BilingualText("Online stores, Meesho/Amazon & dropshipping", "ऑनलाइन स्टोर, मीशो/अमेज़न और रीसेलिंग"),
            iconKey = "shopping",
            accentHex = 0xFFEA580C
        ),
        IdeaCategory(
            id = "social_media",
            name = BilingualText("Social Media Management", "सोशल मीडिया मैनेजमेंट"),
            subtitle = BilingualText("Reels agencies, page growth & brand deals", "रील्स एजेंसी, पेज ग्रोथ और ब्रांड मैनेजमेंट"),
            iconKey = "campaign",
            accentHex = 0xFFDB2777
        ),
        IdeaCategory(
            id = "mobile_only",
            name = BilingualText("Mobile-Only Earning", "सिर्फ मोबाइल से कमाई"),
            subtitle = BilingualText("Run an entire income stream from your phone", "केवल स्मार्टफोन से पूरी कमाई का सिस्टम"),
            iconKey = "smartphone",
            accentHex = 0xFF0284C7
        ),
        IdeaCategory(
            id = "teaching",
            name = BilingualText("Teaching & Online Tutoring", "टीचिंग और ऑनलाइन ट्यूशन"),
            subtitle = BilingualText("Live classes, spoken English & exam coaching", "लाइव क्लास, स्पोकन इंग्लिश और एग्जाम कोचिंग"),
            iconKey = "cast_education",
            accentHex = 0xFF4F46E5
        ),
        IdeaCategory(
            id = "local_business",
            name = BilingualText("Local Small Business", "स्थानीय छोटा व्यवसाय"),
            subtitle = BilingualText("High-demand neighborhood shops & kiosks", "स्थानीय बाज़ार में ज़्यादा मांग वाले छोटे व्यापार"),
            iconKey = "store",
            accentHex = 0xFF0D4A3E
        ),
        IdeaCategory(
            id = "food_tiffin",
            name = BilingualText("Home Food & Tiffin Services", "होम फूड और टिफिन सेवा"),
            subtitle = BilingualText("Cloud kitchens, homemade snacks & meal boxes", "क्लाउड किचन, होममेड स्नैक्स और टिफिन बॉक्स"),
            iconKey = "restaurant",
            accentHex = 0xFFC2410C
        ),
        IdeaCategory(
            id = "local_services",
            name = BilingualText("Services & Local Agency", "लोकल सर्विस और एजेंसी"),
            subtitle = BilingualText("Repair, events, photography & B2B services", "रिपेयर, इवेंट्स, फोटोग्राफी और लोकल एजेंसी"),
            iconKey = "build",
            accentHex = 0xFF334155
        ),
        IdeaCategory(
            id = "crafts_pod",
            name = BilingualText("Crafts & Print-on-Demand", "हैंडमेड और प्रिंट-ऑन-डिमांड"),
            subtitle = BilingualText("Custom tees, gifts, candles & handmade decor", "कस्टम टी-शर्ट, गिफ्ट्स, कैंडल्स और हैंडमेड डेकोर"),
            iconKey = "palette",
            accentHex = 0xFFBE185D
        )
    )

    val byId: Map<String, IdeaCategory> = allCategories.associateBy { it.id }
}
