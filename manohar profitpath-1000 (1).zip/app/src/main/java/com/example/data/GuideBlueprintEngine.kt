package com.example.data

import com.example.model.BilingualText
import com.example.model.GuideStep
import com.example.model.InvestmentLevel
import com.example.model.MasterGuide
import com.example.model.MoneyIdea
import com.example.model.SubGuideDetail
import com.example.model.WorkMode

/**
 * Generates a structured 6-Step Master Roadmap + 6 Deep Interactive Sub-Guides ("Guide inside a Guide")
 * tailored to every single idea (#1 to #1040) in both English and Hindi.
 */
object GuideBlueprintEngine {

    fun buildMasterGuide(idea: MoneyIdea): MasterGuide {
        val category = IdeaRepository.getCategoryById(idea.categoryId)
        val playbook = CategoryPlaybooks.forCategory(idea.categoryId)

        val enTitle = idea.title.en
        val hiTitle = idea.title.hi
        val enNiche = idea.nicheTag.en
        val hiNiche = idea.nicheTag.hi

        val modeHintEn = when (idea.workMode) {
            WorkMode.ONLINE -> "100% online digital setup"
            WorkMode.OFFLINE -> "high-visibility neighborhood & local setup"
            WorkMode.HYBRID -> "smart local + WhatsApp/online hybrid setup"
        }
        val modeHintHi = when (idea.workMode) {
            WorkMode.ONLINE -> "पूरी तरह ऑनलाइन डिजिटल सेटअप"
            WorkMode.OFFLINE -> "स्थानीय बाज़ार और प्रत्यक्ष ग्राहक सेटअप"
            WorkMode.HYBRID -> "लोकल और ऑनलाइन हाइब्रिड सेटअप"
        }

        val budgetNoteEn = when (idea.investmentLevel) {
            InvestmentLevel.ZERO -> "Keep upfront spend strictly at ₹0 by using free tiers until your first ₹5,000 in revenue."
            InvestmentLevel.LOW -> "Start lean with a micro-pilot budget (₹2K–₹15K) focused only on essential starter materials."
            InvestmentLevel.MEDIUM -> "Split your budget 60% into core setup/inventory and keep 40% as working capital for 3 months."
        }
        val budgetNoteHi = when (idea.investmentLevel) {
            InvestmentLevel.ZERO -> "अपनी पहली ₹5,000 कमाई आने तक केवल फ्री टूल्स का उपयोग करें और खर्च ₹0 रखें।"
            InvestmentLevel.LOW -> "शुरुआत में ₹2,000–₹15,000 के सीमित बजट में केवल ज़रूरी सामग्री से पायलट टेस्ट करें।"
            InvestmentLevel.MEDIUM -> "अपने बजट का 60% मुख्य सेटअप में लगाएं और 40% अगले 3 महीनों के वर्किंग कैपिटल के रूप में सुरक्षित रखें।"
        }

        val deviceNoteEn = if (idea.mobileOnly) {
            "Everything in this step can be completed smoothly using just your smartphone."
        } else {
            "Use a laptop/desktop for faster execution, paired with your smartphone for quick daily updates."
        }
        val deviceNoteHi = if (idea.mobileOnly) {
            "इस चरण का हर काम आप केवल अपने स्मार्टफोन से आसानी से पूरा कर सकते हैं।"
        } else {
            "तेज़ काम के लिए लैपटॉप का उपयोग करें और रोज़ाना अपडेट के लिए स्मार्टफोन साथ रखें।"
        }

        val steps = listOf(
            // STEP 1
            GuideStep(
                stepNumber = 1,
                phaseTitle = BilingualText(
                    "Niche Validation & Competitor Research",
                    "बाज़ार रिसर्च और सही ग्राहक की पहचान"
                ),
                summary = BilingualText(
                    "Study real buyer demand for $enTitle in the $enNiche market before spending time or money.",
                    "$hiNiche क्षेत्र में '$hiTitle' की असली मांग और ग्राहकों की ज़रूरत को समझें।"
                ),
                actionBullets = listOf(
                    BilingualText("Identify 5 successful peers already offering $enTitle.", "'$hiTitle' में पहले से सफल 5 उदाहरण या प्रतिस्पर्धी देखें।"),
                    BilingualText("List the top 3 customer complaints or unmet needs you can solve better.", "ग्राहकों की 3 मुख्य समस्याएं लिखें जिन्हें आप बेहतर तरीके से हल कर सकते हैं।"),
                    BilingualText("Define your exact starter target buyer and entry price point.", "अपने पहले आदर्श ग्राहक और शुरुआती कीमत को तय करें।")
                ),
                subGuide = SubGuideDetail(
                    stepNumber = 1,
                    title = BilingualText(
                        "Deep Research Playbook for $enTitle",
                        "'$hiTitle' के लिए विस्तृत रिसर्च गाइड"
                    ),
                    estimatedTime = BilingualText("Days 1–2 (3–4 Hours)", "दिन 1–2 (3–4 घंटे)"),
                    microSteps = listOf(
                        BilingualText("Search '$enTitle' on YouTube, Instagram, and Google to note the top 5 active players.", "यूट्यूब, इंस्टाग्राम और गूगल पर '$hiTitle' खोजकर टॉप 5 सफल उदाहरण नोट करें।"),
                        BilingualText("Read 20+ real comments or reviews to capture exact words buyers use for their pain points.", "कम से कम 20 ग्राहक रिव्यू या कमेंट पढ़ें ताकि उनकी असली भाषा और ज़रूरत समझ आ सके।"),
                        BilingualText("Write a 1-sentence positioning statement: Who you help + What result + How fast.", "1 वाक्य में अपना लक्ष्य लिखें: किसकी मदद करनी है + क्या परिणाम मिलेगा + कितने समय में।"),
                        BilingualText("Talk to 5 potential buyers (friends, local contacts, or online groups) to validate willingness to pay.", "5 संभावित ग्राहकों से सीधे बात करें कि क्या वे इसके लिए भुगतान करेंगे।"),
                        BilingualText("Finalize 1 focused starter offer instead of a confusing catalog of 10 things.", "10 चीज़ों की बजाय 1 स्पष्ट और दमदार शुरुआती ऑफर तय करें।")
                    ),
                    requiredTools = playbook.setupTools,
                    setupWalkthrough = BilingualText(
                        "Open a clean notebook or Google Sheet titled '$enTitle Blueprint'. Create 3 columns: Competitor/Example, What Customers Love, and Gap I Can Fill Better. $budgetNoteEn $deviceNoteEn",
                        "एक नोटबुक या गूगल शीट में '$hiTitle ब्लूप्रिंट' नाम से 3 कॉलम बनाएं: सफल उदाहरण, ग्राहकों को क्या पसंद है, और मैं क्या बेहतर दे सकता हूँ। $budgetNoteHi $deviceNoteHi"
                    ),
                    mistakesToAvoid = listOf(
                        playbook.coreMistakeStep1,
                        BilingualText("Copying a huge established brand instead of starting with a nimble beginner angle.", "बड़े ब्रांड की नकल करना—शुरुआत में तेज़, पर्सनल और सरल सेवा ही आपकी ताकत है।"),
                        BilingualText("Spending weeks over-researching without talking to a single real buyer.", "हफ्तों तक केवल रिसर्च करते रहना और एक भी असली ग्राहक से बात न करना।")
                    )
                )
            ),

            // STEP 2
            GuideStep(
                stepNumber = 2,
                phaseTitle = BilingualText(
                    "Core Setup, Accounts & Brand Foundation",
                    "ज़रूरी सेटअप, अकाउंट और ब्रांड की नींव"
                ),
                summary = BilingualText(
                    "Build your lean $modeHintEn using ${playbook.primaryPlatform.en} so buyers trust you instantly.",
                    "${playbook.primaryPlatform.hi} की मदद से अपना $modeHintHi तैयार करें ताकि ग्राहक आप पर तुरंत भरोसा करें।"
                ),
                actionBullets = listOf(
                    BilingualText("Set up your primary presence on ${playbook.primaryPlatform.en}.", "${playbook.primaryPlatform.hi} पर अपना प्रोफेशनल अकाउंट व प्रोफाइल बनाएं।"),
                    BilingualText("Create a simple memorable brand name, clean profile bio, and contact channel.", "एक आसान ब्रांड नाम, स्पष्ट बायो और संपर्क चैनल (व्हाट्सएप/ईमेल) तैयार करें।"),
                    BilingualText("Configure UPI / payment collection and a basic expense tracker sheet.", "यूपीआई/पेमेंट कलेक्शन और आय-व्यय का सरल ट्रैकर सेट करें।")
                ),
                subGuide = SubGuideDetail(
                    stepNumber = 2,
                    title = BilingualText(
                        "Zero-Friction Setup Checklist",
                        "आसान और तेज़ सेटअप चेकलिस्ट"
                    ),
                    estimatedTime = BilingualText("Days 3–5 (4–6 Hours)", "दिन 3–5 (4–6 घंटे)"),
                    microSteps = listOf(
                        BilingualText("Pick a short, easy-to-spell name related to $enNiche and check availability.", "$hiNiche से जुड़ा एक छोटा, यादगार और बोलने में आसान नाम चुनें।"),
                        BilingualText("Design a crisp logo and banner in Canva in 20 minutes using 2 brand colors.", "कैनवा में 2 रंगों का उपयोग करके 20 मिनट में साफ़ लोगो और बैनर बनाएं।"),
                        BilingualText("Set up dedicated ${playbook.primaryPlatform.en} profile with clear offer, hours, and CTA.", "${playbook.primaryPlatform.hi} पर अपना ऑफर, कार्य समय और संपर्क विवरण साफ़ लिखें।"),
                        BilingualText("Enable instant payment collection (UPI QR, Razorpay/Cosmofeed, or bank ledger).", "तुरंत पेमेंट लेने के लिए यूपीआई क्यूआर या ऑनलाइन पेमेंट लिंक चालू करें।"),
                        BilingualText("Check essential legal basics (Udyam MSME free registration, or FSSAI if food-related).", "आवश्यक बेसिक रजिस्ट्रेशन (जैसे फ्री उद्यम MSME, या फूड काम में FSSAI) जांचें।")
                    ),
                    requiredTools = playbook.setupTools,
                    setupWalkthrough = BilingualText(
                        "Do not get stuck perfecting logos. Follow the 80/20 rule: a clear profile photo, a 2-line bio stating exactly what '$enTitle' delivers, a clickable WhatsApp/order link, and a separate UPI/account ledger to track every rupee in and out. $budgetNoteEn",
                        "सिर्फ लोगो या सजावट में हफ्ते न गंवाएं। 80/20 नियम अपनाएं: साफ़ प्रोफाइल फोटो, 2 लाइन का स्पष्ट परिचय कि '$hiTitle' से क्या फायदा है, सीधा संपर्क लिंक और अलग आय-व्यय रजिस्टर। $budgetNoteHi"
                    ),
                    mistakesToAvoid = listOf(
                        playbook.coreMistakeStep2,
                        BilingualText("Mixing personal pocket money with business cash so you never know your true profit.", "निजी खर्च और बिज़नेस की कमाई को एक साथ मिला देना।"),
                        BilingualText("Leaving your bio or contact details incomplete so interested buyers drop off.", "संपर्क नंबर, कीमत का अंदाज़ा या ऑर्डर करने का तरीका स्पष्ट न लिखना।")
                    )
                )
            ),

            // STEP 3
            GuideStep(
                stepNumber = 3,
                phaseTitle = BilingualText(
                    "Build Your Signature Offer & First Samples",
                    "पहला प्रोडक्ट, सैंपल या कंटेंट तैयार करना"
                ),
                summary = BilingualText(
                    "Create 3 high-quality showcase samples or your first minimum viable batch for $enTitle.",
                    "'$hiTitle' के लिए 3 दमदार सैंपल या पहला तैयार बैच बनाकर ग्राहकों को दिखाने योग्य बनाएं।"
                ),
                actionBullets = listOf(
                    BilingualText("Produce your first 3 proof-of-work samples, trial packs, or flagship content pieces.", "अपने काम का भरोसा दिलाने के लिए पहले 3 बेहतरीन सैंपल या ट्रायल पैक बनाएं।"),
                    BilingualText("Calculate exact unit cost, time required, and target profit margin (minimum 35%+).", "सटीक लागत, लगने वाला समय और कम से कम 35% शुद्ध मुनाफा तय करें।"),
                    BilingualText("Design a clear 1-page rate card or menu/catalog buyers can understand in 10 seconds.", "एक साफ़ 1-पेज रेट कार्ड या कैटलॉग बनाएं जिसे ग्राहक 10 सेकंड में समझ सकें।")
                ),
                subGuide = SubGuideDetail(
                    stepNumber = 3,
                    title = BilingualText(
                        "Crafting an Irresistible Starter Offer",
                        "आकर्षक शुरुआती ऑफर तैयार करने की गाइड"
                    ),
                    estimatedTime = BilingualText("Week 2 (5–8 Hours)", "सप्ताह 2 (5–8 घंटे)"),
                    microSteps = listOf(
                        BilingualText("Structure 3 simple tiers: Starter (easy yes), Standard (best value), and Premium.", "3 आसान पैकेज बनाएं: शुरुआती (कम कीमत), स्टैंडर्ड (सबसे लोकप्रिय) और प्रीमियम।"),
                        BilingualText("Create 3 real samples of $enTitle using the creation tools listed below.", "नीचे दिए टूल्स की मदद से '$hiTitle' के 3 असली सैंपल तैयार करें।"),
                        BilingualText("Shoot crisp daylight photos or a 30-second demo clip explaining the key benefit.", "दिन की रोशनी में साफ़ फोटो या 30-सेकंड का छोटा डेमो वीडियो बनाएं।"),
                        BilingualText("Add a risk-reducer (e.g., quick trial, sample preview, or 1 free revision).", "ग्राहक की झिझक हटाने के लिए ट्रायल सैंपल, प्रीव्यू या 1 फ्री बदलाव की सुविधा दें।"),
                        BilingualText("Test the full customer journey yourself from inquiry to delivery before going public.", "लॉन्च से पहले खुद ग्राहक बनकर पूरी प्रक्रिया जांच लें।")
                    ),
                    requiredTools = playbook.creationTools,
                    setupWalkthrough = BilingualText(
                        "Great execution beats fancy ads. Focus on making your first 3 outputs for '$enTitle' visibly neat, punctual, and well-packaged. Save your workflow as a reusable template/checklist so every future order takes half the time. $deviceNoteEn",
                        "बड़े विज्ञापन से ज़्यादा असरदार आपका काम होता है। '$hiTitle' के पहले 3 सैंपल इतने साफ़, आकर्षक और समयबद्ध बनाएं कि देखने वाला तुरंत प्रभावित हो जाए। अपनी प्रक्रिया को चेकलिस्ट बना लें ताकि आगे काम तेज़ हो। $deviceNoteHi"
                    ),
                    mistakesToAvoid = listOf(
                        playbook.coreMistakeStep3,
                        BilingualText("Offering too many custom variations upfront which slows down delivery and burns you out.", "शुरू में ही बहुत ज़्यादा कस्टम विकल्प देना जिससे काम अटकता है और समय बर्बाद होता है।"),
                        BilingualText("Hiding prices completely—clear starting prices filter out time-wasters.", "कीमत की कोई जानकारी न देना—स्पष्ट शुरुआती रेट सही ग्राहकों को आकर्षित करते हैं।")
                    )
                )
            ),

            // STEP 4
            GuideStep(
                stepNumber = 4,
                phaseTitle = BilingualText(
                    "Launch & Get Your First 10 Customers / Audience",
                    "लॉन्च और पहले 10 ग्राहक या दर्शक पाना"
                ),
                summary = BilingualText(
                    "Execute a focused 14-day launch sprint using ${playbook.launchChannel.en}.",
                    "${playbook.launchChannel.hi} के माध्यम से 14-दिन का दमदार लॉन्च स्प्रिंट चलाएं।"
                ),
                actionBullets = listOf(
                    BilingualText("Announce your launch across warm contacts, groups, and ${playbook.launchChannel.en}.", "अपने परिचितों, ग्रुप्स और ${playbook.launchChannel.hi} पर लॉन्च की घोषणा करें।"),
                    BilingualText("Follow a daily outreach/publishing quota (10 genuine reach-outs or 1 helpful post/day).", "रोज़ का लक्ष्य रखें—प्रतिदिन 10 सही लोगों से संपर्क या 1 उपयोगी पोस्ट/रील।"),
                    BilingualText("Collect written or 15-second video testimonials from every early customer.", "हर शुरुआती ग्राहक से लिखित रिव्यू या 15-सेकंड का फीडबैक ज़रूर लें।")
                ),
                subGuide = SubGuideDetail(
                    stepNumber = 4,
                    title = BilingualText(
                        "First-10-Customers Launch Blueprint",
                        "पहले 10 ग्राहक पाने का प्रैक्टिकल फॉर्मूला"
                    ),
                    estimatedTime = BilingualText("Weeks 2–4 (1–2 Hours/Day)", "सप्ताह 2–4 (रोज़ 1–2 घंटे)"),
                    microSteps = listOf(
                        BilingualText("Message 25 warm contacts personally (not copy-paste spam) asking for feedback or referrals.", "25 परिचितों को सम्मानपूर्वक पर्सनल मैसेज भेजकर फीडबैक या रेफरल मांगें।"),
                        BilingualText("Publish 7 short value posts/Reels showing behind-the-scenes of your $enTitle work.", "'$hiTitle' के पीछे की मेहनत और रिज़ल्ट दिखाते हुए 7 छोटे वीडियो या पोस्ट डालें।"),
                        BilingualText("Offer a 'Founding 10 Buyers' introductory perk to create urgency and fast social proof.", "पहले 10 ग्राहकों के लिए विशेष लॉन्च ऑफर रखें ताकि जल्दी रिव्यू और ऑर्डर मिलें।"),
                        BilingualText("Follow up politely 48 hours after every inquiry—most sales happen on follow-up #2.", "हर पूछताछ के 48 घंटे बाद विनम्रता से फॉलो-अप करें—ज़्यादातर बिक्री यहीं से होती है।"),
                        BilingualText("Screenshot every happy client message and feature it on your profile/catalog.", "हर खुश ग्राहक के मैसेज या रिव्यू को अपने स्टेटस और प्रोफाइल पर साझा करें।")
                    ),
                    requiredTools = playbook.growthTools,
                    setupWalkthrough = BilingualText(
                        "Momentum comes from daily action, not viral luck. Block 60 focused minutes every morning purely for distribution via ${playbook.launchChannel.en}. Track every lead in a simple 4-column sheet: Name, Source, Status, Next Follow-Up Date.",
                        "सफलता किस्मत से नहीं बल्कि रोज़ाना के प्रयास से मिलती है। हर सुबह 60 मिनट केवल मार्केटिंग और ${playbook.launchChannel.hi} पर दें। हर पूछताछ को 4 कॉलम में लिखें: नाम, स्रोत, स्थिति और अगली फॉलो-अप तारीख।"
                    ),
                    mistakesToAvoid = listOf(
                        BilingualText("Posting once, getting 20 views, and assuming nobody wants your offer.", "सिर्फ 1-2 बार पोस्ट करके कम व्यूज़ देखकर हिम्मत हार जाना।"),
                        BilingualText("Sounding desperate or begging—lead with how '$enTitle' saves time, money, or effort.", "गिड़गिड़ाने की बजाय आत्मविश्वास से बताएं कि '$hiTitle' ग्राहक की कौन सी समस्या हल करता है।"),
                        BilingualText("Forgetting to ask satisfied buyers for a referral to 2 friends.", "खुश ग्राहक से उनके 2 दोस्तों को रेफर करने का अनुरोध न करना।")
                    )
                )
            ),

            // STEP 5
            GuideStep(
                stepNumber = 5,
                phaseTitle = BilingualText(
                    "Monetization, Pricing & Repeat Cash Flow",
                    "कमाई के तरीके, प्राइसिंग और नियमित आय"
                ),
                summary = BilingualText(
                    "Maximize profit per customer via ${playbook.monetizationMethod.en}.",
                    "${playbook.monetizationMethod.hi} के ज़रिए प्रति ग्राहक मुनाफा और नियमित आय बढ़ाएं।"
                ),
                actionBullets = listOf(
                    BilingualText("Activate core monetization: ${playbook.monetizationMethod.en}.", "मुख्य कमाई का चैनल सक्रिय करें: ${playbook.monetizationMethod.hi}।"),
                    BilingualText("Introduce a recurring weekly/monthly package or combo upsell to boost lifetime value.", "स्थायी कमाई के लिए मासिक प्लान, रिटेनर या कॉम्बो अपसेल जोड़ें।"),
                    BilingualText("Review profit margins every Sunday and cut unprofitable tasks or SKUs.", "हर रविवार आय-व्यय की समीक्षा करें और कम मुनाफे वाले काम हटाएं।")
                ),
                subGuide = SubGuideDetail(
                    stepNumber = 5,
                    title = BilingualText(
                        "Profit & Monetization Optimization Guide",
                        "मुनाफा और कमाई बढ़ाने की विस्तृत गाइड"
                    ),
                    estimatedTime = BilingualText("Month 2 Onward", "दूसरे महीने से निरंतर"),
                    microSteps = listOf(
                        BilingualText("Map your exact unit profit: Selling Price minus Materials, Fees, Delivery & Time.", "शुद्ध मुनाफा निकालें: बिक्री मूल्य में से सामग्री, फीस, डिलीवरी और समय की लागत घटाएं।"),
                        BilingualText("Switch from one-time sales to recurring plans (monthly retainers, subscriptions, or refill reminders).", "एक बार की बिक्री को मासिक सब्सक्रिप्शन, रिटेनर या रिपीट रिमाइंडर में बदलें।"),
                        BilingualText("Create 1 high-margin add-on (express delivery, combo bundle, or VIP support).", "एक हाई-मार्जिन ऐड-ऑन जोड़ें (जैसे तेज़ डिलीवरी, कॉम्बो पैक या प्रीमियम सपोर्ट)।"),
                        BilingualText("Raise prices by 15%–20% for new buyers once you have 10+ strong reviews.", "10+ अच्छे रिव्यू मिलने के बाद नए ग्राहकों के लिए कीमत में 15%–20% की बढ़ोतरी करें।"),
                        BilingualText("Reinvest 20% of monthly net profit into better tools, inventory, or targeted ads.", "मासिक शुद्ध मुनाफे का 20% बेहतर टूल्स, स्टॉक या प्रचार में दोबारा निवेश करें।")
                    ),
                    requiredTools = playbook.growthTools,
                    setupWalkthrough = BilingualText(
                        "Target earning potential for '$enTitle' is ${idea.earningPotential.en}. Break that monthly goal into a daily number (e.g., 2 sales/day or 6 monthly retainers). Automate payment reminders and keep a separate savings buffer for taxes and upgrades.",
                        "'$hiTitle' में अनुमानित कमाई ${idea.earningPotential.hi} है। अपने मासिक लक्ष्य को दैनिक संख्या में बांटें (जैसे रोज़ 2 ऑर्डर या 6 मासिक क्लाइंट)। पेमेंट रिमाइंडर व्यवस्थित रखें और मुनाफे का एक हिस्सा सुरक्षित बचत में रखें।"
                    ),
                    mistakesToAvoid = listOf(
                        BilingualText("Competing only on the lowest price—quality, speed, and trust always win long-term.", "सिर्फ सबसे सस्ता बेचने की होड़ करना—क्वालिटी, समयबद्धता और भरोसा हमेशा जीतता है।"),
                        BilingualText("Giving credit/udhaar without written due dates which blocks your cash flow.", "बिना लिखित तारीख के उधार देना जिससे आपका कैश-फ्लो रुक जाता है।"),
                        BilingualText("Relying on a single client or single platform for 100% of your income.", "पूरी कमाई के लिए सिर्फ 1 क्लाइंट या 1 ही प्लेटफॉर्म पर निर्भर रहना।")
                    )
                )
            ),

            // STEP 6
            GuideStep(
                stepNumber = 6,
                phaseTitle = BilingualText(
                    "Scaling, Systems & Long-Term Brand Growth",
                    "बिज़नेस को बढ़ाना, सिस्टम और ब्रांड निर्माण"
                ),
                summary = BilingualText(
                    "Turn $enTitle from solo hustle into a smooth, repeatable business system.",
                    "'$hiTitle' को अकेले की मेहनत से बढ़ाकर एक व्यवस्थित और स्थायी ब्रांड में बदलें।"
                ),
                actionBullets = listOf(
                    BilingualText(playbook.scaleMove.en, playbook.scaleMove.hi),
                    BilingualText("Document your repeatable checklists (SOPs) so a helper can maintain your quality.", "अपने काम के सभी चरणों की चेकलिस्ट (SOP) लिख लें ताकि सहायक भी वही क्वालिटी दे सके।"),
                    BilingualText("Build a direct customer list (WhatsApp/Email) you own independently of algorithms.", "ग्राहकों की अपनी व्हाट्सएप/ईमेल लिस्ट बनाएं जो किसी एल्गोरिदम पर निर्भर न हो।")
                ),
                subGuide = SubGuideDetail(
                    stepNumber = 6,
                    title = BilingualText(
                        "Scaling From Side Income to Full Business",
                        "साइड इनकम से बड़े बिज़नेस तक पहुँचने का प्लान"
                    ),
                    estimatedTime = BilingualText("Months 3–6+", "महीना 3–6 और आगे"),
                    microSteps = listOf(
                        BilingualText("Identify the top 20% of products/services bringing 80% of your profit and focus there.", "उन टॉप 20% सेवाओं/उत्पादों को पहचानें जो 80% मुनाफा दे रहे हैं और उन्हीं पर फोकस बढ़ाएं।"),
                        BilingualText("Write step-by-step SOP checklists for ordering, delivery, and customer support.", "ऑर्डर लेने, तैयार करने और डिलीवरी करने की लिखित चेकलिस्ट बनाएं।"),
                        BilingualText("Delegate repetitive tasks (editing, packing, delivery, or admin) to a part-time assistant.", "दोहराए जाने वाले काम (पैकिंग, एडिटिंग या डिलीवरी) के लिए पार्ट-टाइम सहायक रखें।"),
                        BilingualText("Launch a referral reward program (e.g., 10% off or free bonus for every referred friend).", "रेफरल रिवॉर्ड शुरू करें (जैसे दोस्त को जोड़ने पर 10% छूट या फ्री बोनस)।"),
                        BilingualText("Expand into a second complementary revenue stream (digital guide, wholesale, or new locality).", "दूसरा पूरक आय स्रोत जोड़ें (जैसे डिजिटल गाइड, थोक सप्लाई या नया क्षेत्र)।")
                    ),
                    requiredTools = playbook.growthTools,
                    setupWalkthrough = BilingualText(
                        "Scale only after your unit profit is proven and repeat customers return naturally. Next major milestone for '$enTitle': ${playbook.scaleMove.en}. Track monthly revenue, net profit %, and customer repeat rate on the 1st of every month.",
                        "तभी विस्तार करें जब आपका मुनाफा पक्का हो और पुराने ग्राहक बार-बार लौटें। '$hiTitle' का अगला बड़ा पड़ाव: ${playbook.scaleMove.hi}। हर महीने की 1 तारीख को कुल बिक्री, शुद्ध मुनाफा और रिपीट ग्राहकों की संख्या जांचें।"
                    ),
                    mistakesToAvoid = listOf(
                        BilingualText("Hiring full-time staff or renting an expensive shop before steady monthly demand exists.", "स्थिर मासिक मांग बने बिना भारी किराया या स्थायी स्टाफ का बोझ ले लेना।"),
                        BilingualText("Letting product or service quality drop as order volume grows.", "ऑर्डर बढ़ने के साथ क्वालिटी या ग्राहक व्यवहार में लापरवाही आने देना।"),
                        BilingualText("Stopping marketing whenever you feel busy—always keep a steady lead pipeline.", "व्यस्त होने पर मार्केटिंग पूरी तरह बंद कर देना—प्रचार की निरंतरता बनाए रखें।")
                    )
                )
            )
        )

        return MasterGuide(
            idea = idea,
            category = category,
            steps = steps
        )
    }
}
