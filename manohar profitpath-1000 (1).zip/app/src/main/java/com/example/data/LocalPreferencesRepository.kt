package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.earnPediaDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "earnpedia_local_storage"
)

class LocalPreferencesRepository(private val context: Context) {

    private object Keys {
        val BOOKMARKED_IDS = stringSetPreferencesKey("bookmarked_idea_ids")
        val SELECTED_LANGUAGE = stringPreferencesKey("selected_language")
        val COMPLETED_MICRO_STEPS = stringSetPreferencesKey("completed_micro_steps")
    }

    val bookmarkedIds: Flow<Set<Int>> = context.earnPediaDataStore.data.map { prefs ->
        prefs[Keys.BOOKMARKED_IDS]
            ?.mapNotNull { it.toIntOrNull() }
            ?.toSet()
            ?: emptySet()
    }

    val selectedLanguage: Flow<AppLanguage> = context.earnPediaDataStore.data.map { prefs ->
        when (prefs[Keys.SELECTED_LANGUAGE]) {
            AppLanguage.HI.code -> AppLanguage.HI
            else -> AppLanguage.EN
        }
    }

    val completedMicroSteps: Flow<Set<String>> = context.earnPediaDataStore.data.map { prefs ->
        prefs[Keys.COMPLETED_MICRO_STEPS] ?: emptySet()
    }

    suspend fun toggleBookmark(ideaId: Int) {
        context.earnPediaDataStore.edit { prefs ->
            val current = prefs[Keys.BOOKMARKED_IDS]?.toMutableSet() ?: mutableSetOf()
            val key = ideaId.toString()
            if (current.contains(key)) {
                current.remove(key)
            } else {
                current.add(key)
            }
            prefs[Keys.BOOKMARKED_IDS] = current
        }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.earnPediaDataStore.edit { prefs ->
            prefs[Keys.SELECTED_LANGUAGE] = language.code
        }
    }

    suspend fun toggleMicroStep(stepKey: String) {
        context.earnPediaDataStore.edit { prefs ->
            val current = prefs[Keys.COMPLETED_MICRO_STEPS]?.toMutableSet() ?: mutableSetOf()
            if (current.contains(stepKey)) {
                current.remove(stepKey)
            } else {
                current.add(stepKey)
            }
            prefs[Keys.COMPLETED_MICRO_STEPS] = current
        }
    }
}
