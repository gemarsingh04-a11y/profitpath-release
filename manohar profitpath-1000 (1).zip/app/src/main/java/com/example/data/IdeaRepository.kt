package com.example.data

import com.example.data.catalog.IdeasCommerceAndSocial
import com.example.data.catalog.IdeasCreatorAndOnline
import com.example.data.catalog.IdeasLocalAndCraft
import com.example.data.catalog.IdeasRemoteAndDigital
import com.example.model.IdeaCategory
import com.example.model.InvestmentLevel
import com.example.model.MoneyIdea
import com.example.model.QuickFilter
import com.example.model.WorkMode

object IdeaRepository {

    val categories: List<IdeaCategory> = CategoryCatalog.allCategories

    val allIdeas: List<MoneyIdea> by lazy {
        buildList(1040) {
            addAll(IdeasCreatorAndOnline.load())
            addAll(IdeasRemoteAndDigital.load())
            addAll(IdeasCommerceAndSocial.load())
            addAll(IdeasLocalAndCraft.load())
        }
    }

    private val ideasById: Map<Int, MoneyIdea> by lazy {
        allIdeas.associateBy { it.id }
    }

    private val countsByCategory: Map<String, Int> by lazy {
        allIdeas.groupingBy { it.categoryId }.eachCount()
    }

    fun getIdeaById(id: Int): MoneyIdea? = ideasById[id]

    fun getCategoryById(id: String): IdeaCategory =
        CategoryCatalog.byId[id] ?: categories.first()

    fun getCountForCategory(categoryId: String): Int =
        countsByCategory[categoryId] ?: 0

    fun filterIdeas(
        query: String = "",
        categoryId: String? = null,
        quickFilter: QuickFilter = QuickFilter.ALL
    ): List<MoneyIdea> {
        val trimmed = query.trim().lowercase()
        val numericLookup = trimmed.removePrefix("#").toIntOrNull()

        return allIdeas.filter { idea ->
            if (categoryId != null && idea.categoryId != categoryId) return@filter false

            val matchesQuickFilter = when (quickFilter) {
                QuickFilter.ALL -> true
                QuickFilter.ZERO_INVESTMENT -> idea.investmentLevel == InvestmentLevel.ZERO
                QuickFilter.MOBILE_ONLY -> idea.mobileOnly
                QuickFilter.ONLINE -> idea.workMode == WorkMode.ONLINE
                QuickFilter.OFFLINE -> idea.workMode == WorkMode.OFFLINE || idea.workMode == WorkMode.HYBRID
            }
            if (!matchesQuickFilter) return@filter false

            if (trimmed.isEmpty()) return@filter true

            if (numericLookup != null && idea.id == numericLookup) return@filter true

            val cat = CategoryCatalog.byId[idea.categoryId]
            idea.title.en.lowercase().contains(trimmed) ||
                idea.title.hi.lowercase().contains(trimmed) ||
                idea.nicheTag.en.lowercase().contains(trimmed) ||
                idea.nicheTag.hi.lowercase().contains(trimmed) ||
                idea.summary.en.lowercase().contains(trimmed) ||
                idea.summary.hi.lowercase().contains(trimmed) ||
                (cat?.name?.en?.lowercase()?.contains(trimmed) == true) ||
                (cat?.name?.hi?.lowercase()?.contains(trimmed) == true)
        }
    }
}
