package com.example.data.catalog

import com.example.model.BilingualText
import com.example.model.DifficultyLevel
import com.example.model.InvestmentLevel
import com.example.model.MoneyIdea
import com.example.model.WorkMode

internal data class IdeaSeed(
    val enTitle: String,
    val hiTitle: String,
    val enNiche: String,
    val hiNiche: String,
    val earningEn: String,
    val earningHi: String,
    val invest: InvestmentLevel,
    val difficulty: DifficultyLevel,
    val mode: WorkMode,
    val mobileOnly: Boolean
)

internal fun buildCategoryIdeas(
    startId: Int,
    categoryId: String,
    categorySummaryEn: String,
    categorySummaryHi: String,
    defaultSkillsEn: String,
    defaultSkillsHi: String,
    seeds: List<IdeaSeed>
): List<MoneyIdea> {
    return seeds.mapIndexed { index, seed ->
        val investText = when (seed.invest) {
            InvestmentLevel.ZERO -> BilingualText("₹0 (Free to Start)", "₹0 (बिना निवेश)")
            InvestmentLevel.LOW -> BilingualText("₹2,000 – ₹15,000", "₹2,000 – ₹15,000")
            InvestmentLevel.MEDIUM -> BilingualText("₹20,000 – ₹1,00,000", "₹20,000 – ₹1,00,000")
        }
        val firstIncome = when (seed.difficulty) {
            DifficultyLevel.BEGINNER -> BilingualText("1 – 4 Weeks", "1 – 4 सप्ताह")
            DifficultyLevel.INTERMEDIATE -> BilingualText("1 – 3 Months", "1 – 3 महीने")
            DifficultyLevel.ADVANCED -> BilingualText("3 – 6 Months", "3 – 6 महीने")
        }
        MoneyIdea(
            id = startId + index,
            categoryId = categoryId,
            title = BilingualText(seed.enTitle, seed.hiTitle),
            summary = BilingualText(
                "Launch a focused ${seed.enTitle.lowercase()} venture in the ${seed.enNiche.lowercase()} space. $categorySummaryEn",
                "${seed.hiNiche} क्षेत्र में '${seed.hiTitle}' शुरू करें। $categorySummaryHi"
            ),
            earningPotential = BilingualText(seed.earningEn, seed.earningHi),
            investmentLevel = seed.invest,
            investmentText = investText,
            difficulty = seed.difficulty,
            workMode = seed.mode,
            mobileOnly = seed.mobileOnly,
            requiredSkills = BilingualText(defaultSkillsEn, defaultSkillsHi),
            timeToFirstIncome = firstIncome,
            nicheTag = BilingualText(seed.enNiche, seed.hiNiche)
        )
    }
}
