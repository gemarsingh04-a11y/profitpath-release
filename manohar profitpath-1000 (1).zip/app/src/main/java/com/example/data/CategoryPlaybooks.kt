package com.example.data

import com.example.model.BilingualText
import com.example.model.ToolItem

internal data class CategoryPlaybook(
    val primaryPlatform: BilingualText,
    val setupTools: List<ToolItem>,
    val creationTools: List<ToolItem>,
    val growthTools: List<ToolItem>,
    val monetizationMethod: BilingualText,
    val launchChannel: BilingualText,
    val scaleMove: BilingualText,
    val coreMistakeStep1: BilingualText,
    val coreMistakeStep2: BilingualText,
    val coreMistakeStep3: BilingualText
)

internal object CategoryPlaybooks {

    fun forCategory(categoryId: String): CategoryPlaybook = playbooks[categoryId] ?: defaultPlaybook

    private val defaultPlaybook = CategoryPlaybook(
        primaryPlatform = BilingualText("WhatsApp Business, Google Business Profile & UPI", "व्हाट्सएप बिज़नेस, गूगल बिज़नेस प्रोफाइल और यूपीआई"),
        setupTools = listOf(
            ToolItem("WhatsApp Business", BilingualText("Catalog, auto-replies & customer orders", "कैटलॉग, ऑटो-रिप्लाई और ग्राहक ऑर्डर"), BilingualText("Free", "फ्री")),
            ToolItem("Google Business Profile", BilingualText("Local discovery on Google Search & Maps", "गूगल सर्च और मैप्स पर लोकल पहचान"), BilingualText("Free", "फ्री")),
            ToolItem("UPI / Razorpay", BilingualText("Instant payment links & digital receipts", "तुरंत पेमेंट लिंक और डिजिटल रसीद"), BilingualText("Free / 2%", "फ्री / 2%"))
        ),
        creationTools = listOf(
            ToolItem("Canva", BilingualText("Branded rate cards, flyers & social posts", "रेट कार्ड, पोस्टर और सोशल मीडिया डिज़ाइन"), BilingualText("Freemium", "फ्री / पेड")),
            ToolItem("Google Sheets", BilingualText("Pricing, expenses & customer tracker", "कीमत, खर्च और ग्राहक रिकॉर्ड ट्रैकर"), BilingualText("Free", "फ्री")),
            ToolItem("VN / CapCut", BilingualText("Quick promo videos & customer demos", "प्रोमो वीडियो और डेमो एडिटिंग"), BilingualText("Free", "फ्री"))
        ),
        growthTools = listOf(
            ToolItem("Instagram Reels", BilingualText("Organic reach & trust-building proof", "ऑर्गेनिक रीच और ग्राहकों का भरोसा"), BilingualText("Free", "फ्री")),
            ToolItem("Google Forms", BilingualText("Order intake & customer feedback surveys", "ऑर्डर फॉर्म और ग्राहक फीडबैक"), BilingualText("Free", "फ्री")),
            ToolItem("Vyapar / Zoho Invoice", BilingualText("GST-ready bills & monthly profit reports", "बिलिंग और मासिक मुनाफा रिपोर्ट"), BilingualText("Freemium", "फ्री / पेड"))
        ),
        monetizationMethod = BilingualText("Direct service/product sales, repeat subscriptions, and referral bundles", "सीधी बिक्री, मासिक पैकेज और रेफरल बंडल्स"),
        launchChannel = BilingualText("WhatsApp contacts, local community groups, and Instagram Reels", "व्हाट्सएप नेटवर्क, लोकल कम्युनिटी ग्रुप्स और इंस्टाग्राम रील्स"),
        scaleMove = BilingualText("Standardize delivery SOPs, hire a part-time assistant, and launch recurring plans", "काम का स्टैंडर्ड सिस्टम बनाएं, सहायक जोड़ें और मासिक प्लान शुरू करें"),
        coreMistakeStep1 = BilingualText("Trying to serve everyone instead of starting with one clear buyer problem", "सबको बेचने की कोशिश करना, बजाय एक स्पष्ट ग्राहक समस्या हल करने के"),
        coreMistakeStep2 = BilingualText("Overspending on branding or office setup before getting your first 5 paying buyers", "पहले 5 ग्राहक मिलने से पहले सजावट या महंगे सेटअप पर ज़्यादा खर्च करना"),
        coreMistakeStep3 = BilingualText("Underpricing your offer so low that profit disappears after hidden costs", "कीमत इतनी कम रखना कि छुपे खर्चों के बाद मुनाफा ही न बचे")
    )

    private val playbooks: Map<String, CategoryPlaybook> = mapOf(
        "youtube" to CategoryPlaybook(
            primaryPlatform = BilingualText("YouTube Studio, Shorts & Community Tab", "यूट्यूब स्टूडियो, शॉर्ट्स और कम्युनिटी टैब"),
            setupTools = listOf(
                ToolItem("YouTube Studio", BilingualText("Channel analytics, CTR & retention tracking", "चैनल एनालिटिक्स, सीटीआर और वॉच-टाइम"), BilingualText("Free", "फ्री")),
                ToolItem("Google Docs", BilingualText("Video scripts, hooks & content calendar", "वीडियो स्क्रिप्ट, हुक और कंटेंट कैलेंडर"), BilingualText("Free", "फ्री")),
                ToolItem("VidIQ / TubeBuddy", BilingualText("Keyword research & title optimization", "कीवर्ड रिसर्च और टाइटल ऑप्टिमाइजेशन"), BilingualText("Freemium", "फ्री / पेड"))
            ),
            creationTools = listOf(
                ToolItem("CapCut / VN Editor", BilingualText("Fast cuts, auto-captions & pacing", "तेज़ वीडियो एडिटिंग और ऑटो कैप्शन"), BilingualText("Free", "फ्री")),
                ToolItem("Canva / PixelLab", BilingualText("High-contrast clickable thumbnails", "आकर्षक और क्लिकेबल थंबनेल डिज़ाइन"), BilingualText("Free", "फ्री")),
                ToolItem("Lexis Audio / Audacity", BilingualText("Clean voiceover noise reduction", "साफ़ और प्रोफेशनल वॉइस रिकॉर्डिंग"), BilingualText("Free", "फ्री"))
            ),
            growthTools = listOf(
                ToolItem("YouTube Analytics", BilingualText("Spot drop-off seconds & winning topics", "दर्शक कहाँ वीडियो छोड़ते हैं यह समझना"), BilingualText("Free", "फ्री")),
                ToolItem("Linktree / Beacons", BilingualText("Monetize bio with affiliate & sponsor links", "बायो में एफिलिएट और स्पॉन्सर लिंक"), BilingualText("Free", "फ्री")),
                ToolItem("Google AdSense", BilingualText("Partner Program ad revenue payouts", "यूट्यूब पार्टनर प्रोग्राम से एड कमाई"), BilingualText("Free", "फ्री"))
            ),
            monetizationMethod = BilingualText("YouTube AdSense, affiliate product links in descriptions, and niche brand sponsorships", "यूट्यूब एडसेंस, डिस्क्रिप्शन में एफिलिएट लिंक और ब्रांड स्पॉन्सरशिप"),
            launchChannel = BilingualText("YouTube Shorts + 2 long-form searchable videos every week", "हर सप्ताह यूट्यूब शॉर्ट्स और 2 सर्च-आधारित लॉन्ग वीडियो"),
            scaleMove = BilingualText("Batch-script 4 videos at once, hire a freelance editor, and launch a digital guide", "एक साथ 4 वीडियो स्क्रिप्ट करें, एडिटर रखें और अपनी डिजिटल गाइड लॉन्च करें"),
            coreMistakeStep1 = BilingualText("Uploading random topics on one channel which confuses the YouTube algorithm", "एक ही चैनल पर अलग-अलग विषय डालना जिससे एल्गोरिदम कन्फ्यूज़ होता है"),
            coreMistakeStep2 = BilingualText("Waiting to buy an expensive DSLR camera instead of starting with your smartphone", "महंगे कैमरे का इंतज़ार करना जबकि स्मार्टफोन से आज ही शुरू किया जा सकता है"),
            coreMistakeStep3 = BilingualText("Ignoring the first 5-second hook and thumbnail contrast before filming", "पहले 5 सेकंड के हुक और थंबनेल की स्पष्टता पर ध्यान न देना")
        ),
        "affiliate" to CategoryPlaybook(
            primaryPlatform = BilingualText("Amazon Associates, Flipkart, EarnKaro & Impact", "अमेज़न एसोसिएट्स, फ्लिपकार्ट, अर्नकरो और इम्पैक्ट"),
            setupTools = listOf(
                ToolItem("Amazon Associates / EarnKaro", BilingualText("Generate tracked affiliate commission links", "ट्रैक्ड एफिलिएट कमीशन लिंक बनाना"), BilingualText("Free", "फ्री")),
                ToolItem("Bitly / Linktree", BilingualText("Clean clickable bio storefront & click stats", "साफ़ लिंक और क्लिक ट्रैकिंग"), BilingualText("Free", "फ्री")),
                ToolItem("Telegram / WhatsApp Channel", BilingualText("Instant broadcast of curated deals", "डील्स और ऑफर्स तुरंत शेयर करना"), BilingualText("Free", "फ्री"))
            ),
            creationTools = listOf(
                ToolItem("Canva", BilingualText("Comparison charts & deal banners", "तुलना चार्ट और डील्स बैनर बनाना"), BilingualText("Free", "फ्री")),
                ToolItem("CapCut / InShot", BilingualText("30-second product demo & unboxing Reels", "30-सेकंड प्रोडक्ट रिव्यू रील्स"), BilingualText("Free", "फ्री")),
                ToolItem("Keepa / PriceHistory", BilingualText("Verify genuine price drops before posting", "असली प्राइस ड्रॉप की जांच करना"), BilingualText("Free", "फ्री"))
            ),
            growthTools = listOf(
                ToolItem("Pinterest & YouTube Shorts", BilingualText("Evergreen buyer-intent discovery traffic", "लगातार खरीदारों का ऑर्गेनिक ट्रैफिक"), BilingualText("Free", "फ्री")),
                ToolItem("Google Sheets", BilingualText("Track top-converting products & EPC", "सबसे ज़्यादा बिकने वाले प्रोडक्ट्स ट्रैक करना"), BilingualText("Free", "फ्री")),
                ToolItem("WordPress / Blogger", BilingualText("Searchable comparison articles for Google", "गूगल सर्च के लिए रिव्यू आर्टिकल्स"), BilingualText("Freemium", "फ्री / पेड"))
            ),
            monetizationMethod = BilingualText("Per-sale affiliate commissions (2%–40%), recurring SaaS referrals, and sponsored placements", "हर सेल पर 2%–40% कमीशन, रेकरिंग रेफरल और स्पॉन्सर्ड पोस्ट"),
            launchChannel = BilingualText("Comparison Reels, Telegram Deal Channel, and honest buyer-guide posts", "प्रोडक्ट तुलना रील्स, टेलीग्राम डील्स चैनल और ईमानदार बायर गाइड"),
            scaleMove = BilingualText("Double down on high-ticket & recurring SaaS programs and capture email/WhatsApp subscribers", "ज़्यादा कमीशन वाले प्रोडक्ट्स चुनें और अपना व्हाट्सएप/ईमेल सब्सक्राइबर बेस बनाएं"),
            coreMistakeStep1 = BilingualText("Spamming raw affiliate links in comments without explaining who the product helps", "बिना सही जानकारी दिए हर जगह सीधे एफिलिएट लिंक स्पैम करना"),
            coreMistakeStep2 = BilingualText("Promoting poor-quality products just for a high commission which breaks audience trust", "ज़्यादा कमीशन के लालच में खराब प्रोडक्ट प्रमोट करके भरोसा खोना"),
            coreMistakeStep3 = BilingualText("Forgetting to disclose affiliate links or skipping real pros-and-cons comparisons", "प्रोडक्ट के असली फायदे-नुकसान न बताना")
        ),
        "freelancing" to CategoryPlaybook(
            primaryPlatform = BilingualText("Upwork, Fiverr, LinkedIn & Direct Cold Outreach", "अपवर्क, फाइवर, लिंक्डइन और डायरेक्ट क्लाइंट आउटरीच"),
            setupTools = listOf(
                ToolItem("LinkedIn & Fiverr / Upwork", BilingualText("Client discovery & verified profile showcase", "क्लाइंट खोज और प्रोफेशनल प्रोफाइल"), BilingualText("Free", "फ्री")),
                ToolItem("Notion / Google Drive", BilingualText("Clean 3-sample portfolio link ready to share", "3 सैंपल वाला प्रोफेशनल पोर्टफोलियो लिंक"), BilingualText("Free", "फ्री")),
                ToolItem("Razorpay / Payoneer / UPI", BilingualText("Receive Indian & international client payments", "भारतीय और विदेशी क्लाइंट्स से पेमेंट"), BilingualText("Free", "फ्री"))
            ),
            creationTools = listOf(
                ToolItem("Canva / Figma / CapCut", BilingualText("Deliver crisp client work & revisions", "प्रोफेशनल क्लाइंट डिलीवरी और एडिटिंग"), BilingualText("Freemium", "फ्री / पेड")),
                ToolItem("Loom", BilingualText("Record 2-min personalized audit pitches", "2-मिनट का पर्सनल वीडियो पिच रिकॉर्ड करें"), BilingualText("Free", "फ्री")),
                ToolItem("Google Docs", BilingualText("Clear scope proposals & delivery checklists", "स्पष्ट प्रपोज़ल और कॉन्ट्रैक्ट शीट"), BilingualText("Free", "फ्री"))
            ),
            growthTools = listOf(
                ToolItem("Calendly", BilingualText("Frictionless discovery call scheduling", "आसानी से क्लाइंट कॉल बुक करना"), BilingualText("Free", "फ्री")),
                ToolItem("Zoho Invoice", BilingualText("Professional invoices & payment reminders", "प्रोफेशनल बिल और पेमेंट रिमाइंडर"), BilingualText("Free", "फ्री")),
                ToolItem("Trello / Notion", BilingualText("Track multiple client deadlines cleanly", "कई क्लाइंट्स की डेडलाइन मैनेज करना"), BilingualText("Free", "फ्री"))
            ),
            monetizationMethod = BilingualText("Fixed-scope starter packages, monthly retainers (₹15K–₹80K/client), and rush delivery add-ons", "फिक्स्ड प्रोजेक्ट पैकेज और मासिक रिटेनर (₹15K–₹80K प्रति क्लाइंट)"),
            launchChannel = BilingualText("10 personalized value pitches daily on LinkedIn/Email + optimized Fiverr/Upwork gigs", "लिंक्डइन/ईमेल पर रोज़ 10 पर्सनल पिच + फाइवर/अपवर्क प्रोफाइल"),
            scaleMove = BilingualText("Convert one-off projects into monthly retainers and raise rates after every 3 testimonials", "वन-टाइम काम को मासिक रिटेनर में बदलें और हर 3 रिव्यू के बाद रेट बढ़ाएं"),
            coreMistakeStep1 = BilingualText("Listing 10 unrelated skills instead of becoming known for 1 measurable outcome", "10 अलग-अलग काम लिखने की बजाय 1 ठोस रिज़ल्ट देने वाली स्किल न चुनना"),
            coreMistakeStep2 = BilingualText("Waiting for clients to find you without building 3 mock portfolio samples first", "बिना 3 सैंपल पोर्टफोलियो बनाए क्लाइंट का इंतज़ार करना"),
            coreMistakeStep3 = BilingualText("Starting full work without a 50% advance payment or written revision limit", "बिना 50% एडवांस और स्पष्ट रिवीज़न सीमा तय किए काम शुरू करना")
        ),
        "digital_products" to CategoryPlaybook(
            primaryPlatform = BilingualText("Gumroad, Cosmofeed, Topmate & Etsy", "गमरोड, कॉस्मोफीड, टॉपमेट और एत्सी"),
            setupTools = listOf(
                ToolItem("Cosmofeed / Gumroad", BilingualText("Instant UPI/Card checkout & automatic file delivery", "तुरंत यूपीआई/कार्ड पेमेंट और ऑटो फाइल डिलीवरी"), BilingualText("Free + Fee", "फ्री + कमीशन")),
                ToolItem("Notion / Canva / Sheets", BilingualText("Build templates, workbooks & planners", "टेम्पलेट्स, वर्कबुक और प्लानर बनाना"), BilingualText("Free", "फ्री")),
                ToolItem("Google Drive", BilingualText("Organize clean downloadable ZIP/PDF bundles", "डाउनलोडेबल पीडीएफ और बंडल व्यवस्थित करना"), BilingualText("Free", "फ्री"))
            ),
            creationTools = listOf(
                ToolItem("Canva Mockups", BilingualText("3D product covers & preview slides", "3डी प्रोडक्ट कवर और प्रीव्यू इमेज"), BilingualText("Free", "फ्री")),
                ToolItem("Loom / OBS Studio", BilingualText("Short walkthrough video showing how it works", "प्रोडक्ट कैसे काम करता है इसका डेमो वीडियो"), BilingualText("Free", "फ्री")),
                ToolItem("PDFgear / Google Docs", BilingualText("Clean formatting & clickable index links", "साफ़ पीडीएफ फॉर्मेटिंग और इंडेक्स"), BilingualText("Free", "फ्री"))
            ),
            growthTools = listOf(
                ToolItem("Instagram Reels & Pinterest", BilingualText("Show the problem & demo your template", "समस्या दिखाकर अपने टेम्पलेट का डेमो दें"), BilingualText("Free", "फ्री")),
                ToolItem("MailerLite / Substack", BilingualText("Offer a free mini-sample to collect emails", "फ्री सैंपल देकर ईमेल लिस्ट बनाएं"), BilingualText("Free", "फ्री")),
                ToolItem("WhatsApp Broadcast", BilingualText("Upsell new bundles to past buyers", "पुराने खरीदारों को नए बंडल ऑफर करें"), BilingualText("Free", "फ्री"))
            ),
            monetizationMethod = BilingualText("High-margin impulse products (₹199–₹999), mega bundles, and order-bump upsells", "₹199–₹999 के हाई-मार्जिन डिजिटल प्रोडक्ट्स और कॉम्बो बंडल"),
            launchChannel = BilingualText("Demo Reels + Free lead magnet sample + Cosmofeed/Gumroad checkout page", "डेमो रील्स + फ्री सैंपल + इंस्टेंट यूपीआई चेकआउट पेज"),
            scaleMove = BilingualText("Bundle 3 complementary products, add affiliate partners, and run small retargeting ads", "3 प्रोडक्ट्स का कॉम्बो बनाएं, एफिलिएट पार्टनर जोड़ें और रीटारगेटिंग करें"),
            coreMistakeStep1 = BilingualText("Spending 2 months building a huge product before validating demand with a ₹199 starter version", "मांग जांचे बिना महीनों तक बड़ा प्रोडक्ट बनाना—पहले छोटा वर्ज़न लॉन्च करें"),
            coreMistakeStep2 = BilingualText("Using plain text screenshots instead of clear preview mockups showing the end benefit", "साफ़ प्रीव्यू मॉकअप और फायदे न दिखाना"),
            coreMistakeStep3 = BilingualText("Complicated manual delivery instead of automated instant download after payment", "पेमेंट के बाद मैन्युअल फाइल भेजना—ऑटोमैटिक इंस्टेंट डिलीवरी सेट करें")
        ),
        "ecommerce" to CategoryPlaybook(
            primaryPlatform = BilingualText("Meesho, Amazon, Flipkart, Shopify & WhatsApp Catalog", "मीशो, अमेज़न, फ्लिपकार्ट, शॉपिफाई और व्हाट्सएप कैटलॉग"),
            setupTools = listOf(
                ToolItem("Meesho / Amazon Seller App", BilingualText("Zero/low-fee marketplace seller onboarding", "ऑनलाइन सेलर रजिस्ट्रेशन और ऑर्डर पैनल"), BilingualText("Free", "फ्री")),
                ToolItem("Shiprocket / Delhivery", BilingualText("Pan-India COD & prepaid courier pickup", "पूरे भारत में सीओडी और प्रीपेड कूरियर"), BilingualText("Per Order", "प्रति ऑर्डर")),
                ToolItem("WhatsApp Business", BilingualText("Direct COD confirmation to cut RTO returns", "ऑर्डर कन्फर्मेशन जिससे रिटर्न कम हों"), BilingualText("Free", "फ्री"))
            ),
            creationTools = listOf(
                ToolItem("Photoroom / Canva", BilingualText("Clean white-background & lifestyle shots", "साफ़ बैकग्राउंड और प्रोफेशनल प्रोडक्ट फोटो"), BilingualText("Freemium", "फ्री / पेड")),
                ToolItem("IndiaMART / Local Wholesale", BilingualText("Compare verified suppliers & sample quality", "भरोसेमंद थोक सप्लायर और सैंपल जांच"), BilingualText("Free", "फ्री")),
                ToolItem("Google Sheets", BilingualText("Unit economics: product + shipping + RTO margin", "लागत, शिपिंग और शुद्ध मुनाफा गणना"), BilingualText("Free", "फ्री"))
            ),
            growthTools = listOf(
                ToolItem("Instagram Reels & Meta Ads", BilingualText("Product demo videos that trigger instant buys", "प्रोडक्ट डेमो वीडियो से सीधी बिक्री"), BilingualText("Freemium", "फ्री / पेड")),
                ToolItem("GST & Udyam Portal", BilingualText("Official business registration as volume grows", "व्यापार बढ़ने पर जीएसटी और उद्यम पंजीकरण"), BilingualText("Free", "फ्री")),
                ToolItem("Thermal Label Printer", BilingualText("Fast 1-click shipping label packing", "तेज़ शिपिंग लेबल और पैकिंग"), BilingualText("Optional", "वैकल्पिक"))
            ),
            monetizationMethod = BilingualText("Direct retail profit margins (30%–60%), combo upsells, and repeat WhatsApp reorders", "30%–60% रिटेल मार्जिन, कॉम्बो पैक और रिपीट ग्राहक ऑर्डर"),
            launchChannel = BilingualText("Start with 5–10 winning SKUs via WhatsApp/Instagram & marketplace listings", "पहले 5–10 चुनिंदा प्रोडक्ट्स से व्हाट्सएप, इंस्टाग्राम और मार्केटप्लेस पर शुरुआत"),
            scaleMove = BilingualText("Negotiate bulk supplier discounts, reduce RTO via prepaid incentives, and launch private label", "थोक डिस्काउंट लें, प्रीपेड पर छूट देकर रिटर्न घटाएं और अपना ब्रांड लेबल बनाएं"),
            coreMistakeStep1 = BilingualText("Buying huge dead inventory upfront before testing demand with small batches", "डिमांड टेस्ट किए बिना शुरू में ही बहुत सारा माल स्टॉक कर लेना"),
            coreMistakeStep2 = BilingualText("Ignoring return/RTO shipping costs when calculating your selling price", "कीमत तय करते समय रिटर्न और शिपिंग चार्ज की गणना भूल जाना"),
            coreMistakeStep3 = BilingualText("Uploading blurry supplier photos instead of shooting real 15-second demo clips", "धुंधली फोटो डालना—खुद 15-सेकंड का असली वीडियो डेमो शूट करें")
        ),
        "food_tiffin" to CategoryPlaybook(
            primaryPlatform = BilingualText("WhatsApp Groups, Zomato/Swiggy & Apartment Societies", "व्हाट्सएप ग्रुप, ज़ोमैटो/स्विगी और अपार्टमेंट सोसाइटी"),
            setupTools = listOf(
                ToolItem("FoSCoS FSSAI Registration", BilingualText("Mandatory Basic Food Registration (₹100/yr)", "बेसिक FSSAI फूड रजिस्ट्रेशन (₹100/वर्ष)"), BilingualText("₹100/yr", "₹100/वर्ष")),
                ToolItem("WhatsApp Business", BilingualText("Weekly menu broadcast & daily order cutoffs", "साप्ताहिक मेन्यू और डेली ऑर्डर बुकिंग"), BilingualText("Free", "फ्री")),
                ToolItem("Google Business Profile", BilingualText("Rank for 'home tiffin near me' searches", "'मेरे पास टिफिन सेवा' सर्च में रैंक करें"), BilingualText("Free", "फ्री"))
            ),
            creationTools = listOf(
                ToolItem("Canva", BilingualText("Clean weekly menu cards & hygienic sticker labels", "साप्ताहिक मेन्यू कार्ड और बॉक्स स्टिकर"), BilingualText("Free", "फ्री")),
                ToolItem("Food-Grade Containers", BilingualText("Spill-proof microwave-safe meal boxes", "लीक-प्रूफ और स्वच्छ फूड पैकेजिंग"), BilingualText("Low Cost", "कम लागत")),
                ToolItem("Google Sheets", BilingualText("Daily ingredient costing & subscriber ledger", "रोज़ की सामग्री लागत और ग्राहक खाता"), BilingualText("Free", "फ्री"))
            ),
            growthTools = listOf(
                ToolItem("MyGate / Society Flyers", BilingualText("Reach working families & students nearby", "नज़दीकी सोसाइटी, पीजी और ऑफिस तक पहुँच"), BilingualText("Low Cost", "कम लागत")),
                ToolItem("Porter / Local Delivery Boy", BilingualText("Fixed-slot punctual lunch/dinner drop", "तय समय पर लंच/डिनर डिलीवरी"), BilingualText("Per Slot", "प्रति स्लॉट")),
                ToolItem("Zomato / Swiggy Partner", BilingualText("Expand reach once home operations are smooth", "सेटअप स्थिर होने पर ऑनलाइन ऑर्डर बढ़ाएं"), BilingualText("Commission", "कमीशन"))
            ),
            monetizationMethod = BilingualText("Prepaid weekly/monthly meal subscriptions, trial boxes, and weekend specialty add-ons", "प्रीपेड साप्ताहिक/मासिक टिफिन प्लान, ट्रायल मील और वीकेंड स्पेशल"),
            launchChannel = BilingualText("Paid trial tasting meals in 2 nearby apartments, PGs, or office hubs", "पास की 2 सोसाइटी, पीजी या ऑफिस में ट्रायल मील से शुरुआत"),
            scaleMove = BilingualText("Lock 30+ monthly prepaid subscribers, standardize spice mixes, and hire 1 kitchen helper", "30+ मासिक ग्राहक जोड़ें, मसाला माप तय करें और 1 किचन सहायक रखें"),
            coreMistakeStep1 = BilingualText("Offering 30 menu items instead of perfecting 1 signature daily rotating menu", "30 डिश रखने की बजाय 1 स्वादिष्ट और तय साप्ताहिक मेन्यू न बनाना"),
            coreMistakeStep2 = BilingualText("Delivering 20 minutes late during lunch hours—punctuality is #1 in food", "लंच समय पर देर से डिलीवरी करना—समय की पाबंदी सबसे ज़रूरी है"),
            coreMistakeStep3 = BilingualText("Using flimsy leaky containers that ruin presentation and customer trust", "सस्ते और लीक होने वाले डिब्बों का इस्तेमाल करना")
        ),
        "teaching" to CategoryPlaybook(
            primaryPlatform = BilingualText("Zoom / Google Meet, YouTube & WhatsApp Class Groups", "ज़ूम / गूगल मीट, यूट्यूब और व्हाट्सएप बैच ग्रुप"),
            setupTools = listOf(
                ToolItem("Zoom / Google Meet", BilingualText("Live interactive classes with screen share", "स्क्रीन शेयर के साथ लाइव ऑनलाइन क्लास"), BilingualText("Free", "फ्री")),
                ToolItem("WhatsApp Community", BilingualText("Homework, notes & parent updates", "होमवर्क, नोट्स और पेरेंट्स अपडेट"), BilingualText("Free", "फ्री")),
                ToolItem("UPI / Razorpay Links", BilingualText("Advance monthly fee collection & receipts", "एडवांस मासिक फीस और डिजिटल रसीद"), BilingualText("Free", "फ्री"))
            ),
            creationTools = listOf(
                ToolItem("Canva / PowerPoint", BilingualText("Clean visual lesson slides & worksheets", "आकर्षक लेसन स्लाइड्स और वर्कशीट"), BilingualText("Free", "फ्री")),
                ToolItem("Google Classroom / Docs", BilingualText("Structured syllabus, PDFs & weekly tests", "सिलेबस, पीडीएफ नोट्स और साप्ताहिक टेस्ट"), BilingualText("Free", "फ्री")),
                ToolItem("OBS / Whiteboard App", BilingualText("Record lessons for revision & replays", "रिवीजन के लिए क्लास रिकॉर्डिंग"), BilingualText("Free", "फ्री"))
            ),
            growthTools = listOf(
                ToolItem("YouTube / Instagram Demos", BilingualText("Short 2-minute teaching clips that attract students", "2-मिनट के डेमो क्लिप्स से नए छात्र जोड़ें"), BilingualText("Free", "फ्री")),
                ToolItem("Google Forms", BilingualText("Free demo class registration & quizzes", "फ्री डेमो क्लास रजिस्ट्रेशन और टेस्ट"), BilingualText("Free", "फ्री")),
                ToolItem("Classplus / Teachmint", BilingualText("Branded course app when scaling batches", "बैच बढ़ने पर अपना टीचिंग ऐप"), BilingualText("Freemium", "फ्री / पेड"))
            ),
            monetizationMethod = BilingualText("Monthly batch fees, 1-on-1 premium slots, weekend workshops, and study-note bundles", "मासिक बैच फीस, 1-ऑन-1 प्रीमियम ट्यूशन और वीकेंड वर्कशॉप"),
            launchChannel = BilingualText("Host 1 free weekend demo class promoted via WhatsApp groups & short teaching Reels", "व्हाट्सएप ग्रुप और शॉर्ट रील्स के ज़रिए फ्री वीकेंड डेमो क्लास आयोजित करें"),
            scaleMove = BilingualText("Move from 1-on-1 hours to 15-student group cohorts and package recorded revision lessons", "1-ऑन-1 से 15 छात्रों के ग्रुप बैच में शिफ्ट हों और रिकॉर्डेड कोर्स जोड़ें"),
            coreMistakeStep1 = BilingualText("Teaching without a written 4-week syllabus or measurable student outcome", "बिना स्पष्ट 4-सप्ताह सिलेबस और लक्ष्य के पढ़ाना शुरू करना"),
            coreMistakeStep2 = BilingualText("Collecting fees at the end of the month instead of 100% advance before batch start", "महीने के अंत में फीस मांगना—हमेशा बैच शुरू होने से पहले एडवांस फीस लें"),
            coreMistakeStep3 = BilingualText("Skipping parent/student progress updates which drive referrals and renewals", "छात्रों की प्रोग्रेस रिपोर्ट साझा न करना जिससे रेफरल रुकते हैं")
        ),
        "blogging" to CategoryPlaybook(
            primaryPlatform = BilingualText("WordPress / Blogger, Google Search Console & AdSense", "वर्डप्रेस / ब्लॉगर, गूगल सर्च कंसोल और एडसेंस"),
            setupTools = listOf(
                ToolItem("WordPress / Blogger", BilingualText("Fast mobile-friendly publishing CMS", "तेज़ और मोबाइल-फ्रेंडली ब्लॉग प्लेटफॉर्म"), BilingualText("Free / Low", "फ्री / कम")),
                ToolItem("Google Search Console", BilingualText("Index pages & track ranking keywords", "पोस्ट इंडेक्स करना और रैंकिंग ट्रैक करना"), BilingualText("Free", "फ्री")),
                ToolItem("Google Keyword Planner", BilingualText("Find low-competition high-search topics", "कम कॉम्पिटिशन वाले कीवर्ड खोजना"), BilingualText("Free", "फ्री"))
            ),
            creationTools = listOf(
                ToolItem("Google Docs", BilingualText("Draft structured H2/H3 helpful guides", "सुव्यवस्थित और उपयोगी आर्टिकल लिखना"), BilingualText("Free", "फ्री")),
                ToolItem("Canva", BilingualText("Custom featured images & Web Stories", "कस्टम फीचर्ड इमेज और वेब स्टोरीज़"), BilingualText("Free", "फ्री")),
                ToolItem("RankMath / Yoast SEO", BilingualText("On-page titles, schema & readability checks", "ऑन-पेज एसईओ और टाइटल सुधार"), BilingualText("Free", "फ्री"))
            ),
            growthTools = listOf(
                ToolItem("Google AdSense / Mediavine", BilingualText("Display advertising monetization", "ब्लॉग पर डिस्प्ले विज्ञापन से कमाई"), BilingualText("Free", "फ्री")),
                ToolItem("Substack / MailerLite", BilingualText("Capture repeat readers via email digests", "ईमेल सब्सक्राइबर बेस तैयार करना"), BilingualText("Free", "फ्री")),
                ToolItem("Pinterest & Discover", BilingualText("Fast initial traffic before SEO matures", "एसईओ रैंक होने से पहले शुरुआती ट्रैफिक"), BilingualText("Free", "फ्री"))
            ),
            monetizationMethod = BilingualText("Google AdSense display ads, contextual affiliate links, and sponsored brand articles", "गूगल एडसेंस विज्ञापन, एफिलिएट लिंक और स्पॉन्सर्ड आर्टिकल्स"),
            launchChannel = BilingualText("Publish 25 helpful long-tail keyword guides + Pinterest & Google Web Stories", "25 उपयोगी कीवर्ड आर्टिकल्स + पिनटेरेस्ट और गूगल वेब स्टोरीज़"),
            scaleMove = BilingualText("Update top-10 ranking articles quarterly, build topical clusters, and add a newsletter", "टॉप आर्टिकल्स अपडेट रखें, टॉपिक क्लस्टर बनाएं और न्यूज़लेटर जोड़ें"),
            coreMistakeStep1 = BilingualText("Copy-pasting thin articles instead of writing genuinely helpful, original step-by-step answers", "कॉपी-पेस्ट या अधूरे लेख डालना—हमेशा मौलिक और उपयोगी जानकारी लिखें"),
            coreMistakeStep2 = BilingualText("Targeting ultra-competitive broad keywords instead of specific long-tail questions", "कठिन कीवर्ड चुनना—शुरुआत में विशिष्ट लॉन्ग-टेल सवालों पर लिखें"),
            coreMistakeStep3 = BilingualText("Quitting after 10 posts before Google Search has 60–90 days to trust your domain", "सिर्फ 10 पोस्ट लिखकर रुक जाना—ब्लॉगिंग में 60–90 दिन नियमितता ज़रूरी है")
        )
    )
}
