package com.example

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ads.StickyBottomBannerAd
import com.example.model.AppLanguage
import com.example.model.AppStrings
import com.example.model.MainTab
import com.example.ui.components.EarnPediaTopHeader
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MasterGuideScreen
import com.example.ui.screens.SavedScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.theme.EarnPediaTheme
import com.example.viewmodel.EarnPediaUiState
import com.example.viewmodel.EarnPediaViewModel
import com.google.android.gms.ads.MobileAds

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize the official Google Mobile Ads SDK (AdMob)
        MobileAds.initialize(this) {}

        setContent {
            val viewModel: EarnPediaViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            LaunchedEffect(Unit) {
                viewModel.preloadInterstitialAd()
            }

            EarnPediaTheme(isHindi = uiState.language == AppLanguage.HI) {
                EarnPediaAppRoot(
                    uiState = uiState,
                    viewModel = viewModel
                )
            }
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private data class NavTabItem(
    val tab: MainTab,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val badgeCount: Int = 0
)

@Composable
private fun EarnPediaAppRoot(
    uiState: EarnPediaUiState,
    viewModel: EarnPediaViewModel
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }

    val activeMasterGuide = uiState.activeMasterGuide
    if (activeMasterGuide != null) {
        MasterGuideScreen(
            guide = activeMasterGuide,
            activeSubGuide = uiState.activeSubGuideStep,
            language = uiState.language,
            isBookmarked = uiState.bookmarkedIds.contains(activeMasterGuide.idea.id),
            completedMicroSteps = uiState.completedMicroSteps,
            onBack = viewModel::closeMasterGuide,
            onSelectLanguage = viewModel::setLanguage,
            onToggleBookmark = { viewModel.toggleBookmark(activeMasterGuide.idea.id) },
            onOpenSubGuide = viewModel::openSubGuide,
            onCloseSubGuide = viewModel::closeSubGuide,
            onToggleMicroStep = { stepNumber, microIdx ->
                viewModel.toggleMicroStep(activeMasterGuide.idea.id, stepNumber, microIdx)
            }
        )
        return
    }

    val language = uiState.language
    val navItems = listOf(
        NavTabItem(
            tab = MainTab.HOME,
            label = AppStrings.tabHome.get(language),
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home
        ),
        NavTabItem(
            tab = MainTab.CATEGORIES,
            label = AppStrings.tabCategories.get(language),
            selectedIcon = Icons.Filled.GridView,
            unselectedIcon = Icons.Outlined.GridView
        ),
        NavTabItem(
            tab = MainTab.SAVED,
            label = AppStrings.tabSaved.get(language),
            selectedIcon = Icons.Filled.Bookmark,
            unselectedIcon = Icons.Outlined.BookmarkBorder,
            badgeCount = uiState.bookmarkedIds.size
        ),
        NavTabItem(
            tab = MainTab.SEARCH,
            label = AppStrings.tabSearch.get(language),
            selectedIcon = Icons.Filled.Search,
            unselectedIcon = Icons.Outlined.Search
        )
    )

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 840.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                EarnPediaTopHeader(
                    language = language,
                    onSelectLanguage = viewModel::setLanguage
                )
            },
            bottomBar = {
                Column {
                    // Dedicated Sticky Bottom AdMob Banner Slot (AdSize.BANNER)
                    StickyBottomBannerAd(language = language)

                    if (!useNavRail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 2.dp
                        ) {
                            navItems.forEach { item ->
                                val selected = uiState.activeTab == item.tab
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(item.tab) },
                                    modifier = Modifier.testTag("nav_tab_${item.tab.name.lowercase()}"),
                                    icon = {
                                        TabIconWithBadge(item = item, selected = selected)
                                    },
                                    label = {
                                        Text(
                                            text = item.label,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                            maxLines = 1
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                        selectedTextColor = MaterialTheme.colorScheme.primary,
                                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        navItems.forEach { item ->
                            val selected = uiState.activeTab == item.tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { viewModel.selectTab(item.tab) },
                                modifier = Modifier.testTag("rail_tab_${item.tab.name.lowercase()}"),
                                icon = { TabIconWithBadge(item = item, selected = selected) },
                                label = { Text(text = item.label, maxLines = 1) }
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    when (uiState.activeTab) {
                        MainTab.HOME -> HomeScreen(
                            uiState = uiState,
                            onSelectQuickFilter = viewModel::setHomeQuickFilter,
                            onOpenCategory = viewModel::openCategory,
                            onViewAllCategories = {
                                viewModel.closeCategoryDrilldown()
                                viewModel.selectTab(MainTab.CATEGORIES)
                            },
                            onIdeaClick = { idea -> viewModel.onIdeaClicked(idea, activity) },
                            onToggleBookmark = viewModel::toggleBookmark,
                            onLoadMore = viewModel::loadMoreHomeIdeas
                        )
                        MainTab.CATEGORIES -> CategoriesScreen(
                            uiState = uiState,
                            onOpenCategory = viewModel::openCategory,
                            onCloseCategory = viewModel::closeCategoryDrilldown,
                            onSelectCategoryFilter = viewModel::setCategoryQuickFilter,
                            onIdeaClick = { idea -> viewModel.onIdeaClicked(idea, activity) },
                            onToggleBookmark = viewModel::toggleBookmark
                        )
                        MainTab.SAVED -> SavedScreen(
                            uiState = uiState,
                            onIdeaClick = { idea -> viewModel.onIdeaClicked(idea, activity) },
                            onToggleBookmark = viewModel::toggleBookmark,
                            onExploreIdeas = { viewModel.selectTab(MainTab.HOME) }
                        )
                        MainTab.SEARCH -> SearchScreen(
                            uiState = uiState,
                            onQueryChange = viewModel::updateSearchQuery,
                            onSelectCategory = viewModel::setSearchCategory,
                            onSelectQuickFilter = viewModel::setSearchQuickFilter,
                            onResetFilters = viewModel::resetSearchFilters,
                            onIdeaClick = { idea -> viewModel.onIdeaClicked(idea, activity) },
                            onToggleBookmark = viewModel::toggleBookmark,
                            onLoadMore = viewModel::loadMoreSearchResults
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TabIconWithBadge(
    item: NavTabItem,
    selected: Boolean
) {
    val icon = if (selected) item.selectedIcon else item.unselectedIcon
    if (item.badgeCount > 0) {
        BadgedBox(
            badge = {
                Badge(
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor = MaterialTheme.colorScheme.onSecondary
                ) {
                    Text(
                        text = if (item.badgeCount > 99) "99+" else "${item.badgeCount}",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        ) {
            Icon(imageVector = icon, contentDescription = item.label)
        }
    } else {
        Icon(imageVector = icon, contentDescription = item.label)
    }
}
