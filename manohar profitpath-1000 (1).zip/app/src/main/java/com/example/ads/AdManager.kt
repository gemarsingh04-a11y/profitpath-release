package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

/**
 * Centralized Google Mobile Ads (AdMob) Interstitial Manager.
 *
 * Preloads an AdMob InterstitialAd in the background and shows it cleanly on Idea Card clicks.
 * Guarantees `onAdClosedCallback()` is always invoked—whether the user closes the ad, the ad
 * fails to show, or no ad is currently cached—so users never get stuck opening a Master Guide.
 */
class AdManager(private val appContext: Context) {

    private var interstitialAd: InterstitialAd? = null
    private var isLoading: Boolean = false

    fun preloadInterstitial() {
        if (isLoading || interstitialAd != null) return
        isLoading = true

        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            appContext,
            AdsConfig.ADMOB_INTERSTITIAL_UNIT_ID,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    isLoading = false
                    interstitialAd = ad
                    Log.d(TAG, "AdMob Interstitial loaded and ready.")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    isLoading = false
                    interstitialAd = null
                    Log.w(TAG, "AdMob Interstitial failed to load: ${loadAdError.message}")
                }
            }
        )
    }

    fun triggerInterstitialAd(
        activity: Activity?,
        onAdClosedCallback: () -> Unit
    ) {
        val loadedAd = interstitialAd
        if (activity == null || activity.isFinishing || activity.isDestroyed || loadedAd == null) {
            // Ad not ready yet or unavailable — proceed immediately to Master Guide and preload next
            onAdClosedCallback()
            preloadInterstitial()
            return
        }

        // Consume reference immediately so the same ad instance cannot be shown twice
        interstitialAd = null
        var callbackInvoked = false
        fun finishOnce() {
            if (!callbackInvoked) {
                callbackInvoked = true
                onAdClosedCallback()
                preloadInterstitial()
            }
        }

        loadedAd.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "AdMob Interstitial dismissed by user.")
                finishOnce()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "AdMob Interstitial failed to show: ${adError.message}")
                finishOnce()
            }
        }

        loadedAd.show(activity)
    }

    private companion object {
        const val TAG = "EarnPediaAdManager"
    }
}
