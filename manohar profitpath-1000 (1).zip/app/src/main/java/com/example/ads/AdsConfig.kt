package com.example.ads

/**
 * Centralized Google Mobile Ads (AdMob) Configuration.
 */
object AdsConfig {
    /** Dedicated identifier matching `#ad-banner-bottom` for the sticky bottom banner slot. */
    const val BANNER_SLOT_ID: String = "ad_banner_bottom"

    /** Official AdMob Application ID (also declared in AndroidManifest.xml). */
    const val ADMOB_APP_ID: String = "ca-app-pub-3857491573693223~9354589649"

    /** Live AdMob Banner Ad Unit ID (AdSize.BANNER). */
    const val ADMOB_BANNER_UNIT_ID: String = "ca-app-pub-3857491573693223/1804683946"

    /** Live AdMob Interstitial Ad Unit ID triggered before opening a Master Guide. */
    const val ADMOB_INTERSTITIAL_UNIT_ID: String = "ca-app-pub-3857491573693223/4850483834"
}
