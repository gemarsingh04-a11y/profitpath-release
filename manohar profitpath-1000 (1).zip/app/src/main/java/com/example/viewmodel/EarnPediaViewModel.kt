package com.example.viewmodel

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ads.AdManager
import com.example.data.GuideBlueprintEngine
import com.example.data.IdeaRepository
import com.example.data.LocalPreferencesRepository
import com.example.model.AppLanguage
import com.example.model.IdeaCategory
import com.example.model.MainTab
import com.example.model.MasterGuide
import com.example.model.MoneyIdea
import com.example.model.QuickFilter
import com.example.model.SubGuideDetail
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class EarnPediaUiState(
    val language: AppLanguage = AppLanguage.EN,
    val activeTab: MainTab = MainTab.HOME,
    val quickFilter: QuickFilter = QuickFilter.ALL,
    val homeVisibleCount: Int = 30,
    val selectedCategoryId: String? = null,
    val categoryQuickFilter: QuickFilter = QuickFilter.ALL,
    val searchQuery: String = "",
    val searchCategoryId: String? = null,
    val searchQuickFilter: QuickFilter = QuickFilter.ALL,
    val searchVisibleCount: Int = 30,
    val activeMasterGuide: MasterGuide? = null,
    val activeSubGuideStep: SubGuideDetail? = null,
    val bookmarkedIds: Set<Int> = emptySet(),
    val completedMicroSteps: Set<String> = emptySet(),
    val categories: List<IdeaCategory> = IdeaRepository.categories,
    val totalIdeaCount: Int = IdeaRepository.allIdeas.size,
    val homeFilteredIdeas: List<MoneyIdea> = emptyList(),
    val categoryIdeas: List<MoneyIdea> = emptyList(),
    val searchResults: List<MoneyIdea> = emptyList(),
    val savedIdeas: List<MoneyIdea> = emptyList()
)

class EarnPediaViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsRepo = LocalPreferencesRepository(application.applicationContext)
    val adManager = AdManager(application.applicationContext)

    fun preloadInterstitialAd() {
        adManager.preloadInterstitial()
    }

    private data class NavFilterState(
        val activeTab: MainTab = MainTab.HOME,
        val quickFilter: QuickFilter = QuickFilter.ALL,
        val homeVisibleCount: Int = 30,
        val selectedCategoryId: String? = null,
        val categoryQuickFilter: QuickFilter = QuickFilter.ALL,
        val searchQuery: String = "",
        val searchCategoryId: String? = null,
        val searchQuickFilter: QuickFilter = QuickFilter.ALL,
        val searchVisibleCount: Int = 30,
        val activeMasterGuideId: Int? = null,
        val activeSubGuideStepNumber: Int? = null
    )

    private val navState = MutableStateFlow(NavFilterState())

    val uiState: StateFlow<EarnPediaUiState> = combine(
        prefsRepo.selectedLanguage,
        prefsRepo.bookmarkedIds,
        prefsRepo.completedMicroSteps,
        navState
    ) { language, bookmarks, completedSteps, nav ->
        val homeFiltered = IdeaRepository.filterIdeas(
            quickFilter = nav.quickFilter
        )
        val catIdeas = if (nav.selectedCategoryId != null) {
            IdeaRepository.filterIdeas(
                categoryId = nav.selectedCategoryId,
                quickFilter = nav.categoryQuickFilter
            )
        } else {
            emptyList()
        }
        val searchFiltered = IdeaRepository.filterIdeas(
            query = nav.searchQuery,
            categoryId = nav.searchCategoryId,
            quickFilter = nav.searchQuickFilter
        )
        val saved = bookmarks
            .mapNotNull { IdeaRepository.getIdeaById(it) }
            .sortedBy { it.id }

        val masterGuide = nav.activeMasterGuideId
            ?.let { IdeaRepository.getIdeaById(it) }
            ?.let { GuideBlueprintEngine.buildMasterGuide(it) }

        val activeSubGuide = if (masterGuide != null && nav.activeSubGuideStepNumber != null) {
            masterGuide.steps.firstOrNull { it.stepNumber == nav.activeSubGuideStepNumber }?.subGuide
        } else {
            null
        }

        EarnPediaUiState(
            language = language,
            activeTab = nav.activeTab,
            quickFilter = nav.quickFilter,
            homeVisibleCount = nav.homeVisibleCount,
            selectedCategoryId = nav.selectedCategoryId,
            categoryQuickFilter = nav.categoryQuickFilter,
            searchQuery = nav.searchQuery,
            searchCategoryId = nav.searchCategoryId,
            searchQuickFilter = nav.searchQuickFilter,
            searchVisibleCount = nav.searchVisibleCount,
            activeMasterGuide = masterGuide,
            activeSubGuideStep = activeSubGuide,
            bookmarkedIds = bookmarks,
            completedMicroSteps = completedSteps,
            categories = IdeaRepository.categories,
            totalIdeaCount = IdeaRepository.allIdeas.size,
            homeFilteredIdeas = homeFiltered,
            categoryIdeas = catIdeas,
            searchResults = searchFiltered,
            savedIdeas = saved
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = EarnPediaUiState(
            homeFilteredIdeas = IdeaRepository.allIdeas,
            searchResults = IdeaRepository.allIdeas
        )
    )

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            prefsRepo.setLanguage(language)
        }
    }

    fun toggleLanguage() {
        val next = if (uiState.value.language == AppLanguage.EN) AppLanguage.HI else AppLanguage.EN
        setLanguage(next)
    }

    fun selectTab(tab: MainTab) {
        navState.update { it.copy(activeTab = tab) }
    }

    fun setHomeQuickFilter(filter: QuickFilter) {
        navState.update { it.copy(quickFilter = filter, homeVisibleCount = 30) }
    }

    fun loadMoreHomeIdeas() {
        navState.update { it.copy(homeVisibleCount = it.homeVisibleCount + 30) }
    }

    fun openCategory(categoryId: String) {
        navState.update {
            it.copy(
                activeTab = MainTab.CATEGORIES,
                selectedCategoryId = categoryId,
                categoryQuickFilter = QuickFilter.ALL
            )
        }
    }

    fun closeCategoryDrilldown() {
        navState.update { it.copy(selectedCategoryId = null, categoryQuickFilter = QuickFilter.ALL) }
    }

    fun setCategoryQuickFilter(filter: QuickFilter) {
        navState.update { it.copy(categoryQuickFilter = filter) }
    }

    fun updateSearchQuery(query: String) {
        navState.update { it.copy(searchQuery = query, searchVisibleCount = 30) }
    }

    fun setSearchCategory(categoryId: String?) {
        navState.update {
            val next = if (it.searchCategoryId == categoryId) null else categoryId
            it.copy(searchCategoryId = next, searchVisibleCount = 30)
        }
    }

    fun setSearchQuickFilter(filter: QuickFilter) {
        navState.update { it.copy(searchQuickFilter = filter, searchVisibleCount = 30) }
    }

    fun loadMoreSearchResults() {
        navState.update { it.copy(searchVisibleCount = it.searchVisibleCount + 30) }
    }

    fun resetSearchFilters() {
        navState.update {
            it.copy(
                searchQuery = "",
                searchCategoryId = null,
                searchQuickFilter = QuickFilter.ALL,
                searchVisibleCount = 30
            )
        }
    }

    /**
     * Every Idea Card click routes through centralized AdManager.triggerInterstitialAd
     * before opening the Master Guide view.
     */
    fun onIdeaClicked(idea: MoneyIdea, activity: Activity?) {
        adManager.triggerInterstitialAd(
            activity = activity,
            onAdClosedCallback = {
                navState.update {
                    it.copy(
                        activeMasterGuideId = idea.id,
                        activeSubGuideStepNumber = null
                    )
                }
            }
        )
    }

    fun closeMasterGuide() {
        navState.update {
            it.copy(
                activeMasterGuideId = null,
                activeSubGuideStepNumber = null
            )
        }
    }

    fun openSubGuide(stepNumber: Int) {
        navState.update { it.copy(activeSubGuideStepNumber = stepNumber) }
    }

    fun closeSubGuide() {
        navState.update { it.copy(activeSubGuideStepNumber = null) }
    }

    fun toggleBookmark(ideaId: Int) {
        viewModelScope.launch {
            prefsRepo.toggleBookmark(ideaId)
        }
    }

    fun toggleMicroStep(ideaId: Int, stepNumber: Int, microIndex: Int) {
        val key = "${ideaId}_${stepNumber}_${microIndex}"
        viewModelScope.launch {
            prefsRepo.toggleMicroStep(key)
        }
    }
}
