package com.example.model

object AppStrings {
    val appTitle = BilingualText("EarnPedia", "EarnPedia")
    val appTagline = BilingualText("1,040+ Business Guides", "1,040+ बिज़नेस गाइड")

    // Bottom Nav Tabs
    val tabHome = BilingualText("Home", "होम")
    val tabCategories = BilingualText("Categories", "श्रेणियाँ")
    val tabSaved = BilingualText("Saved", "सेव किए गए")
    val tabSearch = BilingualText("Search", "खोजें")

    // Hero Banner
    val heroBadge = BilingualText("ENCYCLOPEDIA • 1,040 IDEAS", "विश्वकोश • 1,040 आइडियाज़")
    val heroHeadline = BilingualText(
        "1000+ Money Making Ideas & Step-by-Step Guides",
        "1000+ पैसे कमाने के तरीके और स्टेप-बाय-स्टेप गाइड"
    )
    val heroSubheadline = BilingualText(
        "Actionable 6-step roadmaps with deep sub-guides for every single idea.",
        "हर आइडिया के लिए 6-स्टेप रोडमैप और अंदर विस्तृत सब-गाइड।"
    )
    val statIdeas = BilingualText("1,040 Ideas", "1,040 आइडिया")
    val statCategories = BilingualText("16 Categories", "16 श्रेणियाँ")
    val statSubGuides = BilingualText("6,240 Sub-Guides", "6,240 सब-गाइड")

    // Quick Filters
    val filterAll = BilingualText("All Ideas", "सभी आइडिया")
    val filterZero = BilingualText("Zero Investment", "जीरो निवेश")
    val filterMobile = BilingualText("Mobile Only", "सिर्फ मोबाइल")
    val filterOnline = BilingualText("Online", "ऑनलाइन")
    val filterOffline = BilingualText("Offline", "ऑफलाइन")
    val filterHybrid = BilingualText("Hybrid", "हाइब्रिड")

    // Difficulty
    val diffBeginner = BilingualText("Beginner", "शुरुआती")
    val diffIntermediate = BilingualText("Intermediate", "मध्यम")
    val diffAdvanced = BilingualText("Advanced", "एडवांस")

    // Home & Lists
    val featuredCategories = BilingualText("Browse Categories", "श्रेणियाँ देखें")
    val viewAll = BilingualText("View All", "सभी देखें")
    val directoryHeading = BilingualText("Complete Directory", "संपूर्ण डायरेक्टरी")
    val loadMore = BilingualText("Load More Ideas", "और आइडिया लोड करें")
    val openGuide = BilingualText("Open Guide", "गाइड पढ़ें")
    val allLoaded = BilingualText("You've reached the end of the list", "सभी परिणाम दिखाए जा चुके हैं")
    val ideasCountSuffix = BilingualText("Ideas", "आइडिया")

    // Categories Screen
    val categoriesHeader = BilingualText("16 Business Categories", "16 बिज़नेस श्रेणियाँ")
    val categoriesSubheader = BilingualText(
        "Tap any category to explore 65 practical step-by-step blueprints",
        "65 व्यावहारिक गाइड देखने के लिए किसी भी श्रेणी पर टैप करें"
    )
    val backToCategories = BilingualText("All Categories", "सभी श्रेणियाँ")

    // Saved Screen
    val savedHeader = BilingualText("Saved Guides", "सेव किए गए गाइड")
    val savedSubheader = BilingualText(
        "Your personal shortlist saved offline on this device",
        "आपके पसंदीदा गाइड जो इस डिवाइस में सुरक्षित हैं"
    )
    val savedEmptyTitle = BilingualText("No Saved Guides Yet", "अभी कोई गाइड सेव नहीं है")
    val savedEmptyBody = BilingualText(
        "Tap the bookmark icon on any money-making idea to save its full 6-step blueprint here for instant access.",
        "किसी भी बिज़नेस आइडिया पर बुकमार्क आइकन दबाएं ताकि आप उसका पूरा 6-स्टेप गाइड यहाँ तुरंत पढ़ सकें।"
    )
    val exploreIdeasCta = BilingualText("Explore 1,040+ Ideas", "1,040+ आइडिया देखें")

    // Search Screen
    val searchHeader = BilingualText("Search Directory", "डायरेक्टरी में खोजें")
    val searchPlaceholder = BilingualText(
        "Search ideas, skills, or #number (e.g. YouTube, #42)...",
        "आइडिया, स्किल या #नंबर खोजें (जैसे YouTube, टिफिन, #42)..."
    )
    val popularSearches = BilingualText("Popular Topics", "लोकप्रिय विषय")
    val noSearchResultsTitle = BilingualText("No Matching Ideas Found", "कोई मिलता-जुलता आइडिया नहीं मिला")
    val noSearchResultsBody = BilingualText(
        "Try clearing a filter chip or searching with simpler keywords in English or Hindi.",
        "कोई फ़िल्टर हटाएं या हिंदी या अंग्रेज़ी में सरल शब्दों से खोजें।"
    )
    val resetFilters = BilingualText("Reset Filters", "फ़िल्टर रीसेट करें")

    // Master Guide Screen
    val masterGuideLabel = BilingualText("MASTER BUSINESS GUIDE", "मास्टर बिज़नेस गाइड")
    val quickOverviewTitle = BilingualText("Quick Overview", "त्वरित विवरण")
    val metricEarning = BilingualText("Est. Earning", "अनुमानित कमाई")
    val metricInvestment = BilingualText("Investment", "निवेश")
    val metricDifficulty = BilingualText("Difficulty", "कठिनाई स्तर")
    val metricSkills = BilingualText("Key Skills", "आवश्यक कौशल")
    val metricFirstIncome = BilingualText("First Income", "पहली कमाई")
    val roadmapHeading = BilingualText("Step-by-Step Roadmap (Steps 1–6)", "स्टेप-बाय-स्टेप रोडमैप (चरण 1–6)")
    val roadmapSubheading = BilingualText(
        "Tap 'View Detailed Sub-Guide' inside any step for micro-steps, apps, setup & mistakes to avoid.",
        "माइक्रो-स्टेप्स, ऐप्स, सेटअप और गलतियों से बचने के लिए हर चरण में 'विस्तृत गाइड देखें' पर टैप करें।"
    )
    val viewDetailedSubGuide = BilingualText("View Detailed Sub-Guide", "विस्तृत गाइड देखें")
    val stepPrefix = BilingualText("Step", "चरण")
    val savedLabel = BilingualText("Saved", "सेव है")
    val saveLabel = BilingualText("Save", "सेव करें")

    // Sub-Guide Sheet ("Guide inside a Guide")
    val subGuideBadge = BilingualText("DEEP SUB-GUIDE • GUIDE INSIDE A GUIDE", "विस्तृत सब-गाइड • गाइड के अंदर गाइड")
    val estTimePrefix = BilingualText("Est. Time:", "अनुमानित समय:")
    val microStepsHeading = BilingualText("Exact Micro-Steps Checklist", "सटीक माइक्रो-स्टेप्स चेकलिस्ट")
    val toolsHeading = BilingualText("Required Tools & Apps", "आवश्यक टूल्स और ऐप्स")
    val setupHeading = BilingualText("Step-by-Step Setup Instructions", "सेटअप करने का पूरा तरीका")
    val mistakesHeading = BilingualText("Beginner Mistakes to Avoid", "शुरुआती गलतियाँ जिनसे बचें")
    val prevStep = BilingualText("Previous Step", "पिछला चरण")
    val nextStep = BilingualText("Next Step", "अगला चरण")
    val doneReading = BilingualText("Done", "बंद करें")

    // Ad Placeholders
    val adTag = BilingualText("AD", "विज्ञापन")
    val bannerPlaceholderTitle = BilingualText("Banner Ad Space • 320×50", "बैनर विज्ञापन स्थान • 320×50")
    val bannerPlaceholderSub = BilingualText("AdMob / AdSense Ready Slot", "AdMob / AdSense के लिए तैयार")
    val interstitialBadge = BilingualText("SPONSORED AD PREVIEW • TEST MODE", "विज्ञापन पूर्वावलोकन • टेस्ट मोड")
    val interstitialTitle = BilingualText("Interstitial Ad Placement", "इंटरस्टिशियल विज्ञापन स्थान")
    val interstitialBody = BilingualText(
        "This 3-second test modal demonstrates the AdManager hook triggered before opening a Master Guide. Replace with live AdMob / Unity Ads SDK in AdsConfig.kt.",
        "यह 3-सेकंड का टेस्ट प्रीव्यू दिखाता है कि गाइड खुलने से पहले AdManager कैसे काम करता है। लाइव AdMob / Unity Ads कोड AdsConfig.kt में जोड़ा जा सकता है।"
    )
    val continueToGuide = BilingualText("Continue to Guide", "गाइड पर जाएं")
    val continueInPrefix = BilingualText("Continue in", "प्रतीक्षा करें")

    fun showingCount(visible: Int, total: Int, language: AppLanguage): String =
        if (language == AppLanguage.HI) "$total में से $visible आइडिया दिख रहे हैं"
        else "Showing $visible of $total ideas"

    fun difficultyLabel(level: DifficultyLevel, language: AppLanguage): String = when (level) {
        DifficultyLevel.BEGINNER -> diffBeginner.get(language)
        DifficultyLevel.INTERMEDIATE -> diffIntermediate.get(language)
        DifficultyLevel.ADVANCED -> diffAdvanced.get(language)
    }

    fun workModeLabel(mode: WorkMode, language: AppLanguage): String = when (mode) {
        WorkMode.ONLINE -> filterOnline.get(language)
        WorkMode.OFFLINE -> filterOffline.get(language)
        WorkMode.HYBRID -> filterHybrid.get(language)
    }

    fun quickFilterLabel(filter: QuickFilter, language: AppLanguage): String = when (filter) {
        QuickFilter.ALL -> filterAll.get(language)
        QuickFilter.ZERO_INVESTMENT -> filterZero.get(language)
        QuickFilter.MOBILE_ONLY -> filterMobile.get(language)
        QuickFilter.ONLINE -> filterOnline.get(language)
        QuickFilter.OFFLINE -> filterOffline.get(language)
    }
}
