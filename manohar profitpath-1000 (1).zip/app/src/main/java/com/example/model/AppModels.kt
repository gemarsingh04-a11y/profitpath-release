package com.example.model

enum class AppLanguage(val code: String) {
    EN("en"),
    HI("hi")
}

data class BilingualText(
    val en: String,
    val hi: String
) {
    fun get(language: AppLanguage): String = if (language == AppLanguage.HI) hi else en
}

enum class InvestmentLevel {
    ZERO,
    LOW,
    MEDIUM
}

enum class WorkMode {
    ONLINE,
    OFFLINE,
    HYBRID
}

enum class DifficultyLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}

enum class QuickFilter {
    ALL,
    ZERO_INVESTMENT,
    MOBILE_ONLY,
    ONLINE,
    OFFLINE
}

enum class MainTab {
    HOME,
    CATEGORIES,
    SAVED,
    SEARCH
}

data class IdeaCategory(
    val id: String,
    val name: BilingualText,
    val subtitle: BilingualText,
    val iconKey: String,
    val accentHex: Long
)

data class MoneyIdea(
    val id: Int,
    val categoryId: String,
    val title: BilingualText,
    val summary: BilingualText,
    val earningPotential: BilingualText,
    val investmentLevel: InvestmentLevel,
    val investmentText: BilingualText,
    val difficulty: DifficultyLevel,
    val workMode: WorkMode,
    val mobileOnly: Boolean,
    val requiredSkills: BilingualText,
    val timeToFirstIncome: BilingualText,
    val nicheTag: BilingualText
)

data class ToolItem(
    val name: String,
    val purpose: BilingualText,
    val costTag: BilingualText
)

data class SubGuideDetail(
    val stepNumber: Int,
    val title: BilingualText,
    val estimatedTime: BilingualText,
    val microSteps: List<BilingualText>,
    val requiredTools: List<ToolItem>,
    val setupWalkthrough: BilingualText,
    val mistakesToAvoid: List<BilingualText>
)

data class GuideStep(
    val stepNumber: Int,
    val phaseTitle: BilingualText,
    val summary: BilingualText,
    val actionBullets: List<BilingualText>,
    val subGuide: SubGuideDetail
)

data class MasterGuide(
    val idea: MoneyIdea,
    val category: IdeaCategory,
    val steps: List<GuideStep>
)
