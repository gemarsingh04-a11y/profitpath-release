package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Editorial Wealth Ledger Palette - Light
val EmeraldPrimary = Color(0xFF0D4A3E)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldContainer = Color(0xFFD2F0E7)
val EmeraldOnContainer = Color(0xFF042921)

val MarigoldSecondary = Color(0xFFC47D0E)
val MarigoldOnSecondary = Color(0xFFFFFFFF)
val MarigoldContainer = Color(0xFFFFEBC8)
val MarigoldOnContainer = Color(0xFF3E2400)

val TerracottaTertiary = Color(0xFFB54D32)
val TerracottaOnTertiary = Color(0xFFFFFFFF)
val TerracottaContainer = Color(0xFFFFDBD2)
val TerracottaOnContainer = Color(0xFF3D0E04)

val IvoryBackground = Color(0xFFFAF8F4)
val CharcoalOnBackground = Color(0xFF171E1C)
val WarmSurface = Color(0xFFFFFFFF)
val WarmSurfaceVariant = Color(0xFFF1ECE2)
val SlateOnSurfaceVariant = Color(0xFF535D5A)
val WarmOutline = Color(0xFFDAD3C5)
val WarmOutlineVariant = Color(0xFFEAE4D8)

// Editorial Wealth Ledger Palette - Dark
val MintPrimaryDark = Color(0xFF52D1A7)
val MintOnPrimaryDark = Color(0xFF00382B)
val MintContainerDark = Color(0xFF095143)
val MintOnContainerDark = Color(0xFFC8F5E5)

val AmberSecondaryDark = Color(0xFFF6BE58)
val AmberOnSecondaryDark = Color(0xFF422A00)
val AmberContainerDark = Color(0xFF5F3E00)
val AmberOnContainerDark = Color(0xFFFFE5B8)

val CoralTertiaryDark = Color(0xFFFFB5A1)
val CoralOnTertiaryDark = Color(0xFF5D1A0B)
val CoralContainerDark = Color(0xFF7D2D1A)
val CoralOnContainerDark = Color(0xFFFFDBD2)

val ObsidianBackground = Color(0xFF0E1513)
val IvoryOnBackgroundDark = Color(0xFFE7ECE9)
val DeepSlateSurface = Color(0xFF151E1C)
val DeepSlateSurfaceVariant = Color(0xFF1F2B28)
val MutedSageOnVariantDark = Color(0xFFA7B5B0)
val DarkOutline = Color(0xFF34433F)
val DarkOutlineVariant = Color(0xFF25322F)

// Semantic Accent Tokens
val SuccessEmerald = Color(0xFF137A55)
val WarningAmber = Color(0xFFD9820B)
val DangerCrimson = Color(0xFFC43B3B)
val GoldAccent = Color(0xFFE59A1D)
val DeepBannerStart = Color(0xFF09362D)
val DeepBannerEnd = Color(0xFF0D4A3E)
